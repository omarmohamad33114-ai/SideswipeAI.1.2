#!/usr/bin/env python3
"""خادم تجريبي لبروتوكول RemoteAdvisor (مكتبة بايثون القياسية فقط). للتجربة فقط: قاعدته بسيطة جدًا.
يجب نشره خلف HTTPS (التطبيق يرفض http). ضع أي مفتاح API هنا في الخادم، لا داخل التطبيق."""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

class H(BaseHTTPRequestHandler):
    def do_POST(self):
        s = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        ball, me = s.get("ball"), s.get("me")
        steer = 0
        if ball and me:
            e = ball[0] - me[0]
            steer = 0 if abs(e) < 0.03 else (1 if e > 0 else -1)
        out = json.dumps({"steer": steer, "boost": False, "jump": False}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(out)

HTTPServer(("0.0.0.0", 8080), H).serve_forever()
