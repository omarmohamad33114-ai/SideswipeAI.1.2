"""نسخة Python مطابقة سطرًا بسطر لـ DecisionEngine.kt / ChaseStrategy لتشغيل سيناريوهات الاختبار هنا.
ليست الكود الفعلي: تتحقق من المنطق فقط، لا من ترجمة Kotlin."""
from dataclasses import dataclass, replace
from typing import Optional
import math

@dataclass
class Obj:
    x: float; y: float; vx: float; vy: float; conf: float = 1.0; vOk: bool = True

@dataclass
class World:
    t: int; ball: Optional[Obj]; me: Optional[Obj]; opp: Optional[Obj]; facing: int = 0

@dataclass
class Decision:
    mode: str; left: bool = False; right: bool = False; boost: bool = False; jump: bool = False; reason: str = ""

@dataclass
class Cfg:
    attackRight: bool = True; deadzone: float = 0.02; minHoldMs: int = 150; behindOffset: float = 0.12
    jumpCooldownMs: int = 900; minConf: float = 0.35; gravity: float = 1.2; carSpeed: float = 0.45
    ballLostHoldMs: int = 500; ballLostSafeMs: int = 4000

class Smart:
    name = "smart"
    def __init__(s, cfg=None):
        s.cfg = cfg or Cfg(); s.groundY = -1.0; s.lastJumpAt = 0; s.lastAirAt = -100000
        s.lastSteer = 0; s.steerSince = 0; s.lostSince = 0; s.last = None
        s.refX = -1.0; s.refT = 0; s.unstickUntil = 0; s.unstickDir = 0
    def decide(s, w): d = s.compute(w); s.last = d; return d
    def predict(s, b, t):
        if not b.vOk: return b.x, b.y
        x, y, vx, vy = b.x, b.y, b.vx, b.vy
        floor = s.groundY if s.groundY > 0 else 0.9
        tt = 0.0
        while tt < t:
            dt = min(0.05, t - tt)
            vy += s.cfg.gravity * dt; x += vx * dt; y += vy * dt
            if x < 0: x = -x; vx = -vx * 0.8
            elif x > 1: x = 2 - x; vx = -vx * 0.8
            if y > floor: y = floor; vy = 0.0 if abs(vy) < 0.25 else -vy * 0.6
            if y < 0: y = 0.0; vy = -vy * 0.5
            tt += dt
        return x, y
    def intercept(s, b, me):
        t = 0.0
        while t <= 1.2:
            px, py = s.predict(b, t)
            if abs(px - me.x) <= s.cfg.carSpeed * t + 0.04: return px, py, t
            t += 0.1
        px, py = s.predict(b, 0.6); return px, py, 0.6
    def compute(s, w):
        c = s.cfg; now = w.t
        me = w.me if (w.me and w.me.conf >= c.minConf) else None
        if me is None: return Decision("SAFE", reason="x")
        d_ = 1 if c.attackRight else -1
        if s.groundY < 0: s.groundY = me.y
        if abs(me.vy) < 0.03: s.groundY += (me.y - s.groundY) * 0.05
        air = me.y < s.groundY - 0.06
        if air: s.lastAirAt = now
        rec = (not air) and now - s.lastAirAt < 300
        if now < s.unstickUntil: return Decision("UNSTICK", left=s.unstickDir < 0, right=s.unstickDir > 0)
        if s.refX < 0: s.refX = me.x; s.refT = now
        elif now - s.refT >= 1500:
            active = bool(s.last and (s.last.left or s.last.right or s.last.boost))
            if active and not air and abs(me.x - s.refX) < 0.01:
                s.unstickUntil = now + 600; s.unstickDir = -s.lastSteer if s.lastSteer != 0 else -d_
            s.refX = me.x; s.refT = now
        ball = w.ball if (w.ball and w.ball.conf >= c.minConf) else None
        if ball is None:
            if s.lostSince == 0: s.lostSince = now
            lf = now - s.lostSince
            if lf < c.ballLostHoldMs and s.last is not None: return replace(s.last, jump=False)
            if lf > c.ballLostSafeMs: return Decision("SAFE")
            e = 0.5 - me.x; st = 0 if abs(e) < 0.05 else (1 if e > 0 else -1)
            return Decision("SEARCH", left=st < 0, right=st > 0)
        s.lostSince = 0
        px, py, tHit = s.intercept(ball, me)
        dx = px - me.x; above = s.groundY - py
        ownGoal = 0.02 if d_ == 1 else 0.98
        onOwn = (ball.x - 0.5) * d_ < -0.2
        toOwn = ball.vOk and ball.vx * d_ < -0.05
        opp = w.opp if (w.opp and w.opp.conf >= c.minConf) else None
        oppCloser = opp is not None and abs(opp.x - ball.x) < abs(me.x - ball.x) - 0.05
        danger = onOwn and (toOwn or oppCloser)
        behind = (me.x - px) * d_ < 0
        if air: mode = "AIR"
        elif danger: mode = "DEFENSE"
        elif rec: mode = "RECOVER"
        elif above > 0.12: mode = "HIGH_BALL"
        elif not behind: mode = "AIM"
        elif abs(dx) > 0.15: mode = "APPROACH"
        else: mode = "STRIKE"
        if mode == "DEFENSE": tx = ownGoal + d_ * 0.18 if abs(px - ownGoal) > 0.55 else px - d_ * 0.04
        elif mode == "AIM": tx = px - d_ * c.behindOffset
        elif mode == "STRIKE": tx = px + d_ * 0.02
        else: tx = px - d_ * 0.03
        err = tx - me.x
        st = 0 if abs(err) < c.deadzone else (1 if err > 0 else -1)
        if air: st = 0
        if st != 0 and s.lastSteer != 0 and st != s.lastSteer and now - s.steerSince < c.minHoldMs: st = s.lastSteer
        if st != s.lastSteer: s.lastSteer = st; s.steerSince = now
        if not air:
            fo = w.facing == 0 or w.facing == st
            boost = st != 0 and fo and not rec and (abs(err) > 0.12 or mode == "STRIKE")
        else: boost = above > 0.08 and abs(dx) < 0.2
        jump = False
        if (not air) and above > 0.12 and tHit < 0.35 and now - s.lastJumpAt > c.jumpCooldownMs:
            rel = px - (me.x + (me.vx if me.vOk else 0.0) * 0.25)
            if abs(rel) < 0.08: jump = True; s.lastJumpAt = now
        return Decision(mode, left=st < 0, right=st > 0, boost=boost, jump=jump)

class Chase:
    name = "chase"
    def __init__(s, cfg=None): s.cfg = cfg or Cfg()
    def decide(s, w):
        c = s.cfg
        if not (w.me and w.me.conf >= c.minConf): return Decision("SAFE")
        if not (w.ball and w.ball.conf >= c.minConf): return Decision("SAFE")
        e = w.ball.x - w.me.x; st = 0 if abs(e) < c.deadzone else (1 if e > 0 else -1)
        return Decision("CHASE", left=st < 0, right=st > 0, boost=st != 0 and abs(e) > 0.15)
