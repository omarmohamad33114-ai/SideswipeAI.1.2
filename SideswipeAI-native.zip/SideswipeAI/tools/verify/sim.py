"""محاكاة لعبة جانبية مبسطة (فيزياء من تأليفي، ليست Rocket League). الغرض: اختبار ثبات المنطق تحت ضجيج،
لا قياس قوة اللعب الحقيقية."""
import random, statistics as st
from mirror import *

G=1.2; GROUND=0.8
def run(Strat, seed, secs=90, noise=0.01, drop=0.1):
    r = random.Random(seed)
    me = dict(x=.3,y=GROUND,vx=0,vy=0); opp=dict(x=.7,y=GROUND,vx=0,vy=0)
    ball = dict(x=.5,y=.5,vx=0,vy=0)
    s = Strat(Cfg(attackRight=True)); oppbot = Chase(Cfg(attackRight=False))
    gf=ga=0; dt=.05; t=0.0; nextTick=0.0; modes={}; flips=0; lastSteer=0; ticks=0; safe=0
    dec = Decision("IDLE"); odec = Decision("IDLE"); touches=0; good=0; lastTouch=-9
    hist=[]  # ball history for velocity estimate
    while t < secs:
        if t >= nextTick:
            nextTick += .15; ticks += 1
            now = int(t*1000)+10000
            def seen(o,c): return Obj(o['x']+r.gauss(0,noise), o['y']+r.gauss(0,noise), o['vx']+r.gauss(0,.05), o['vy']+r.gauss(0,.05), c, True)
            b = None if r.random()<drop else seen(ball,.9)
            dec = s.decide(World(now, b, seen(me,.9), seen(opp,.9), 1 if me['vx']>=0 else -1))
            # الخصم: يرى الصورة معكوسة (يهاجم يسارًا)
            odec = oppbot.decide(World(now, Obj(1-ball['x'],ball['y'],0,0), Obj(1-opp['x'],opp['y'],0,0), None, 0))
            modes[dec.mode]=modes.get(dec.mode,0)+1
            if dec.mode=="SAFE": safe+=1
            sd = (1 if dec.right else 0)-(1 if dec.left else 0)
            if sd!=0 and lastSteer!=0 and sd!=lastSteer: flips+=1
            if sd!=0: lastSteer=sd
        def step(c, left, right, boost, jump):
            a = (2.0 if boost else 1.2); sdir = (1 if right else 0)-(1 if left else 0)
            c['vx'] += sdir*a*dt; c['vx'] *= (1-0.8*dt); c['vx']=max(-.9 if boost else -.6, min(.9 if boost else .6, c['vx']))
            if jump and c['y']>=GROUND-1e-3: c['vy'] = -.9
            c['vy'] += G*dt; c['x']+=c['vx']*dt; c['y']+=c['vy']*dt
            c['x']=max(.02,min(.98,c['x']))
            if c['y']>=GROUND: c['y']=GROUND; c['vy']=0
        step(me, dec.left, dec.right, dec.boost, dec.jump)
        step(opp, odec.right, odec.left, odec.boost, odec.jump)  # معكوس
        ball['vy']+=G*dt; ball['x']+=ball['vx']*dt; ball['y']+=ball['vy']*dt
        if ball['y']>GROUND: ball['y']=GROUND; ball['vy']=-ball['vy']*.6 if abs(ball['vy'])>.25 else 0; ball['vx']*=(1-.5*dt)
        if ball['y']<0: ball['y']=0; ball['vy']=-ball['vy']*.5
        for c,own in ((me,True),(opp,False)):
            if abs(ball['x']-c['x'])<.04 and abs(ball['y']-c['y'])<.06:
                ball['vx'] = c['vx']*1.3 + (0.15 if c['vx']>=0 else -0.15); ball['vy'] = -.35
                if own and t-lastTouch>.5:
                    lastTouch=t; touches+=1; good += ball['vx']>.05
        if ball['x']<=.03 and ball['y']>.55: ga+=1; ball.update(x=.5,y=.5,vx=0,vy=0); me.update(x=.3,vx=0); opp.update(x=.7,vx=0)
        elif ball['x']>=.97 and ball['y']>.55: gf+=1; ball.update(x=.5,y=.5,vx=0,vy=0); me.update(x=.3,vx=0); opp.update(x=.7,vx=0)
        elif ball['x']<=.03 or ball['x']>=.97:
            ball['vx']=-ball['vx']*.8; ball['x']=max(.031,min(.969,ball['x']))
        t+=dt
    return dict(gf=gf,ga=ga,flips=flips/(secs),safe=safe/ticks,touches=touches,good=good,modes=modes)

for S in (Smart, Chase):
    R=[run(S,i) for i in range(30)]
    print(f"{S.name:6} | هدف لي {sum(r['gf'] for r in R):3d} | هدف علي {sum(r['ga'] for r in R):3d} | "
          f"قلب اتجاه/ث {st.mean(r['flips'] for r in R):.2f} | وقت SAFE {st.mean(r['safe'] for r in R)*100:.1f}% | "
          f"لمسات {sum(r['touches'] for r in R)} (نحو المرمى {sum(r['good'] for r in R)})")
tot={}
for r in [run(Smart,i) for i in range(30)]:
    for k,v in r['modes'].items(): tot[k]=tot.get(k,0)+v
n=sum(tot.values()); print("توزيع حالات smart:", {k:f"{v/n*100:.0f}%" for k,v in sorted(tot.items(), key=lambda x:-x[1])})
