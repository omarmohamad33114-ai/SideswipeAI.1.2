plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sideswipeai.plugin"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sideswipeai.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }
    // مفتاح توقيع ثابت داخل المشروع: كل بناء يُوقَّع بنفس المفتاح فيُثبَّت التحديث فوق القديم بدون حذف
    // (مفتاح شخصي للتثبيت اليدوي فقط، لا تستخدمه لنشر التطبيق في المتجر)
    signingConfigs {
        create("shared") {
            storeFile = file("sideswipe.keystore")
            storePassword = "sideswipe123"
            keyAlias = "sideswipe"
            keyPassword = "sideswipe123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("shared") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")   // org.json الحقيقي لاختبارات JVM
}
