package com.sideswipeai.plugin.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import kotlin.random.Random

class ParamTunerTest {
    @Test fun exploresEveryArmOnce() {
        ParamTuner.load(null)
        val seen = HashSet<Int>()
        repeat(3) { seen += ParamTuner.choose(Random(it)); ParamTuner.finish(5, 3) }
        assertEquals(3, seen.size)
    }

    @Test fun shortSessionsAreIgnored() {
        ParamTuner.load(null)
        ParamTuner.choose(Random(1)); ParamTuner.finish(2, 2)
        assertFalse(ParamTuner.summary().contains("جلسة"))
    }
}
