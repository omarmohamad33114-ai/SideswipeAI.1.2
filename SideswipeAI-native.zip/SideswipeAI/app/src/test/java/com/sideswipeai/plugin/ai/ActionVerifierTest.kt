package com.sideswipeai.plugin.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionVerifierTest {
    private fun run(v: ActionVerifier, steer: Int, x: (Int) -> Float?): Boolean {
        var res = false
        for (i in 0..60) res = v.feed(1000L + i * 100L, steer, x(i), 1f) || res
        return res
    }

    @Test fun steeringWithoutMovementIsDetected() =
        assertTrue(run(ActionVerifier(1000, 0.01f, 2), 1) { 0.5f })

    @Test fun movementIsNotAFailure() =
        assertFalse(run(ActionVerifier(1000, 0.01f, 2), 1) { 0.3f + it * 0.01f })

    @Test fun noSteeringIsNotAFailure() =
        assertFalse(run(ActionVerifier(1000, 0.01f, 2), 0) { 0.5f })

    @Test fun undetectedCarGivesNoVerdict() =
        assertFalse(run(ActionVerifier(1000, 0.01f, 2), 1) { null })

    @Test fun carAtWallGivesNoVerdict() =
        assertFalse(run(ActionVerifier(1000, 0.01f, 2), 1) { 0.01f })
}
