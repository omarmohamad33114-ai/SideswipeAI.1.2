package com.sideswipeai.plugin.ai

import com.sideswipeai.plugin.ai.remote.RemoteAdvisor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RemoteAdvisorTest {
    @Test fun parsesValidResponse() {
        val h = RemoteAdvisor.parse("""{"steer":-1,"boost":true,"jump":false}""", 5)
        assertNotNull(h); assertEquals(-1, h!!.steer); assertTrue(h.boost)
    }
    @Test fun rejectsOutOfRangeSteer() = assertNull(RemoteAdvisor.parse("""{"steer":2,"boost":true,"jump":false}""", 1))
    @Test fun rejectsMissingField() = assertNull(RemoteAdvisor.parse("""{"steer":1}""", 1))
    @Test fun rejectsGarbage() = assertNull(RemoteAdvisor.parse("not json", 1))
}
