package com.sideswipeai.plugin.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.sideswipeai.plugin.ErrLog
import com.sideswipeai.plugin.TouchInjectorService
import com.sideswipeai.plugin.ai.AutoPlayer
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

/**
 * طبقة التحكم: تحوّل مجموعة أزرار مطلوبة إلى ضغطات مستمرة عبر dispatchGesture.
 * تُقسَّم الضغطة إلى مقاطع (SEG) متصلة بـ willContinue كي لا يُرفع الإصبع بين المقاطع.
 *
 * وضع الجويستيك (الافتراضي): LEFT/RIGHT لا يضغطان زرين، بل يسحبان إصبعًا واحدًا من مركز الجويستيك
 * إلى يسار/يمين بمقدار نصف القطر، ويبقى الإصبع مضغوطًا ما دام الاتجاه مطلوبًا. القفز والبوست أزرار عادية.
 */
object TouchController {
    enum class Btn(val key: String) { LEFT("btn_left"), RIGHT("btn_right"), JUMP("btn_jump"), BOOST("btn_boost") }

    private const val SEG = 100L
    val points = ConcurrentHashMap<Btn, PointF>()      // إحداثيات معيارية 0..1 من الشاشة
    @Volatile var enabled = false
    @Volatile var lastError = ""
    @Volatile private var desired: Set<Btn> = emptySet()

    // ---- الجويستيك ----
    @Volatile var joystickMode = true
    /** مركز الجويستيك (معياري 0..1). */
    @Volatile var joyCenter: PointF? = null
    /** نصف قطر الجويستيك كنسبة من عرض الشاشة. */
    @Volatile var joyRadius = 0.068f
    private const val JOY_REACH = 0.9f   // نسبة الانحراف من نصف القطر

    // تُستخدم على الخيط الرئيسي فقط
    private val held = HashMap<Btn, GestureDescription.StrokeDescription>()
    private var stickEnd: PointF? = null   // آخر نقطة (بكسل) انتهى عندها مقطع الجويستيك
    private var inFlight = false
    private var sentAt = 0L
    /** متوسط التأخير الإضافي لإرسال لمسة فوق مدة المقطع (مللي ثانية) - قياس فعلي. */
    @Volatile var overheadMs = 0L
    private var fails = 0
    private val main = Handler(Looper.getMainLooper())

    fun setPoint(key: String, x: Float, y: Float) {
        Btn.values().firstOrNull { it.key == key }?.let { points[it] = PointF(x, y) }
    }
    fun setJoystick(x: Float, y: Float, r: Float) { joyCenter = PointF(x, y); joyRadius = r.coerceIn(0.03f, 0.15f) }

    /** كل النقاط التي قد تلمسها اللعبة (للتحقق من عدم تغطية الفقاعة لها). */
    fun allPoints(): List<PointF> {
        val l = ArrayList<PointF>()
        for ((b, p) in points) { if (joystickMode && (b == Btn.LEFT || b == Btn.RIGHT)) continue; l += p }
        joyCenter?.let { l += it }
        return l
    }

    fun pointsJson(): String {
        val parts = ArrayList<String>()
        for ((b, p) in points) { if (joystickMode && (b == Btn.LEFT || b == Btn.RIGHT)) continue; parts += "\"${b.key}\":[${p.x},${p.y}]" }
        joyCenter?.let { parts += "\"joy\":[${it.x},${it.y},$joyRadius]" }
        return parts.joinToString(",", "{", "}")
    }

    fun ready(): Boolean =
        if (joystickMode) joyCenter != null && points.containsKey(Btn.JUMP) && points.containsKey(Btn.BOOST)
        else Btn.values().all { points.containsKey(it) }

    fun start() { enabled = true; fails = 0; lastError = "" }
    fun stop() { enabled = false; desired = emptySet(); main.post { pump() }; main.postDelayed({ pump() }, 1700) }   // يحرّر الأزرار المضغوطة
    fun setDesired(s: Set<Btn>) { desired = s; main.post { pump() } }

    private fun dropHeld() { held.clear(); stickEnd = null }

    private fun fail(msg: String) {
        lastError = msg; enabled = false; desired = emptySet(); dropHeld(); inFlight = false
        ErrLog.add("control", msg)
        AutoPlayer.onControllerError(msg)
        AutoPlayer.emergencyStop("خطأ في التحكم: $msg", "control")
    }

    private fun pump() {
        if (inFlight) {
            if (SystemClock.uptimeMillis() - sentAt < 1500) return
            inFlight = false; dropHeld(); ErrLog.add("control", "تأخر رد النظام على اللمسة")
        }
        val want = if (enabled) desired else emptySet()
        if (want.isEmpty() && held.isEmpty()) return
        val svc: AccessibilityService = TouchInjectorService.instance
            ?: run { if (enabled) fail("خدمة التحكم غير مفعّلة"); dropHeld(); return }
        val (w, h) = TouchInjectorService.instance!!.screenSize()

        // اتجاه الجويستيك: -1 يسار، +1 يمين، 0 محايد (أو الاثنان معًا)
        val dir = if (!joystickMode) 0 else when {
            Btn.LEFT in want && Btn.RIGHT !in want -> -1
            Btn.RIGHT in want && Btn.LEFT !in want -> 1
            else -> 0
        }

        val b = GestureDescription.Builder()
        val next = HashMap<Btn, GestureDescription.StrokeDescription>()
        var newStickEnd: PointF? = null
        var added = 0
        val keys = LinkedHashSet<Btn>()
        keys.addAll(held.keys)
        for (k in want) keys.add(if (joystickMode && k == Btn.RIGHT) Btn.LEFT else k)   // يمين ويسار = إصبع الجويستيك (مفتاحه LEFT)
        for (btn in keys) {
            if (joystickMode && btn == Btn.RIGHT) continue          // يُدمج مع الجويستيك (مفتاحه LEFT)
            val isStick = joystickMode && btn == Btn.LEFT
            val prev = held[btn]
            val path = Path()
            val keep: Boolean
            if (isStick) {
                val c = joyCenter ?: continue
                val cx = c.x * w; val cy = c.y * h
                val tx = cx + dir * joyRadius * w * JOY_REACH
                keep = dir != 0
                if (prev == null) {
                    if (dir == 0) continue                            // لا إصبع على الجويستيك ولا نريد واحدًا
                    path.moveTo(cx, cy); path.lineTo(tx, cy)
                    newStickEnd = PointF(tx, cy)
                } else {
                    val f = stickEnd ?: PointF(cx, cy)
                    path.moveTo(f.x, f.y)
                    if (dir != 0 && abs(f.x - tx) > 1f) path.lineTo(tx, cy)
                    newStickEnd = if (dir != 0) PointF(tx, cy) else f
                }
            } else {
                val pt = points[btn] ?: continue
                path.moveTo(pt.x * w, pt.y * h)
                keep = btn in want
            }
            val s = if (prev == null) GestureDescription.StrokeDescription(path, 0L, SEG, keep)
                    else prev.continueStroke(path, 0L, SEG, keep)
            b.addStroke(s); added++
            if (keep) next[btn] = s
        }
        if (added == 0) { dropHeld(); return }
        val endAfter = newStickEnd
        inFlight = true; sentAt = SystemClock.uptimeMillis()
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val d = (SystemClock.uptimeMillis() - sentAt - SEG).coerceAtLeast(0)
                overheadMs = if (overheadMs == 0L) d else (overheadMs * 8 + d * 2) / 10
                held.clear(); held.putAll(next)
                stickEnd = if (next.containsKey(Btn.LEFT) && joystickMode) endAfter else null
                inFlight = false; fails = 0; pump()
            }
            override fun onCancelled(g: GestureDescription?) {
                dropHeld(); inFlight = false
                if (++fails >= 5) fail("تكرر إلغاء اللمسات") else pump()
            }
        }, main)
        if (!ok) { inFlight = false; dropHeld(); fail("رفض النظام إرسال اللمسة") }
    }
}
