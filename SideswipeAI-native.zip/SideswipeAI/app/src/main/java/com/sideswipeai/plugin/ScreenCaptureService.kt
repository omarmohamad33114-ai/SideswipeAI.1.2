package com.sideswipeai.plugin

import android.app.Notification
import android.app.PendingIntent
import android.graphics.drawable.Icon
import com.sideswipeai.plugin.ai.AutoPlayer
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicReference

/** يلتقط الشاشة بدقة مصغّرة ويحفظ آخر إطار (JPEG) + يستدعي frameListener للرؤية (المرحلة 3). */
class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP_CONTROL = "com.sideswipeai.STOP_CONTROL"
        private const val CHANNEL = "sideswipe_capture"

        @Volatile var instance: ScreenCaptureService? = null
        @Volatile var status = "idle"          // idle | awaiting_permission | denied | running | stopped | error
        @Volatile var frameCount = 0L
        @Volatile var frameW = 0
        @Volatile var frameH = 0
        @Volatile var lastError = ""
        @Volatile var lastFrameAt = 0L
        @Volatile var targetWidth = 540
        @Volatile var intervalMs = 200
        /** للمرحلة 3: يُستدعى على خيط الالتقاط. لا تحتفظ بالـ Bitmap خارجه. */
        @Volatile var frameListener: ((Bitmap) -> Unit)? = null
        @Volatile var lastPreviewAsk = 0L
        val latestJpeg = AtomicReference<ByteArray?>(null)
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var curW = 0
    private var curH = 0
    private var dpi = 320
    private var lastAcceptedAt = 0L
    private var closed = false
    private var reuse: Bitmap? = null
    private var blackRun = 0

    /** يكشف الصورة السوداء المستمرة (تطبيق يمنع الالتقاط FLAG_SECURE أو انتهاء الجلسة). */
    private fun checkBlack(b: Bitmap) {
        var maxLum = 0
        for (i in 0 until 48) {
            val c = b.getPixel((b.width * (i % 8 + 1)) / 9, (b.height * (i / 8 + 1)) / 7)
            maxLum = maxOf(maxLum, (android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3)
        }
        if (maxLum < 8) { if (++blackRun == 40) { lastError = "الصورة سوداء منذ فترة: قد تمنع اللعبة الالتقاط"; ErrLog.add("capture", lastError) } }
        else { if (blackRun >= 40) lastError = ""; blackRun = 0 }
    }
    private var resizing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action != ACTION_STOP_CONTROL && instance != null) return START_NOT_STICKY
        if (intent.action == ACTION_STOP_CONTROL) { AutoPlayer.emergencyStop("إيقاف من الإشعار"); return START_NOT_STICKY }
        try {
            startAsForeground()
            val code = intent.getIntExtra(EXTRA_CODE, 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: throw IllegalStateException("no projection data")
            thread = HandlerThread("capture").also { it.start() }
            handler = Handler(thread!!.looper)
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data).also {
                it.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { shutdown("stopped") }
                }, handler)
            }
            instance = this
            frameCount = 0
            val (w, h) = desiredSize()
            curW = w; curH = h
            reader = newReader(w, h)
            display = projection!!.createVirtualDisplay(
                "SideswipeCapture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
            )
            status = "running"; lastError = ""
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            ErrLog.add("capture", lastError)
            shutdown("error")
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sideswipe AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Sideswipe AI")
            .setContentText("مراقبة الشاشة قيد التشغيل")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف التحكم فورًا",
                PendingIntent.getService(this, 1, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP_CONTROL),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun desiredSize(): Pair<Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        dpi = m.densityDpi
        val w = (targetWidth / 2) * 2
        val h = ((m.heightPixels.toFloat() / m.widthPixels * w).toInt() / 2) * 2
        return w to h
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ onImage(it) }, handler)
        return r
    }

    private fun onImage(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = System.currentTimeMillis()
            if (now - lastAcceptedAt < intervalMs) return
            lastAcceptedAt = now

            // تغيّر اتجاه الشاشة (عمودي/أفقي) أو الدقة المطلوبة
            val (w, h) = desiredSize()
            if ((w != curW || h != curH) && !resizing) { resizing = true; handler?.post { resize(w, h) } }

            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val bw = img.width + rowPadding / pixelStride
            var buf = reuse
            if (buf == null || buf.width != bw || buf.height != img.height) {
                buf?.recycle()
                buf = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888); reuse = buf
            }
            buf.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (rowPadding == 0) buf else Bitmap.createBitmap(buf, 0, 0, img.width, img.height)
            checkBlack(bmp)
            frameListener?.invoke(bmp)
            // JPEG للمعاينة فقط عند طلبها (توفير المعالج)
            if (now - lastPreviewAsk < 2000 || latestJpeg.get() == null) {
                val out = ByteArrayOutputStream(32 * 1024)
                bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
                latestJpeg.set(out.toByteArray())
            }
            frameW = bmp.width; frameH = bmp.height
            if (bmp !== buf) bmp.recycle()
            frameCount++
            lastFrameAt = System.currentTimeMillis()
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            ErrLog.add("capture", lastError)
        } finally {
            img.close()
        }
    }

    private fun resize(w: Int, h: Int) {
        try {
            reader?.close()
            reader = newReader(w, h)
            display?.resize(w, h, dpi)
            display?.surface = reader!!.surface
            curW = w; curH = h
        } catch (e: Exception) { lastError = e.message ?: "resize failed"; ErrLog.add("capture", lastError) }
        resizing = false
    }

    fun shutdown(finalStatus: String) {
        if (closed) return
        closed = true
        AutoPlayer.emergencyStop("توقف التقاط الشاشة", "capture")
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        thread?.quitSafely(); thread = null
        latestJpeg.set(null)
        try { reuse?.recycle() } catch (_: Exception) {}; reuse = null
        status = finalStatus
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (instance != null) shutdown("stopped"); super.onDestroy() }
}
