package com.sideswipeai.plugin

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.sideswipeai.plugin.ai.AutoPlayer
import com.sideswipeai.plugin.ai.ParamTuner
import com.sideswipeai.plugin.ai.Skill
import com.sideswipeai.plugin.ai.remote.RemoteAdvisor
import com.sideswipeai.plugin.ai.Strategies
import com.sideswipeai.plugin.bubble.BubbleService
import com.sideswipeai.plugin.control.TouchController
import org.json.JSONObject

/** الشاشة الرئيسية: زر "اتصال" واحد يمرّ بالأذونات المطلوبة ثم يفتح اللعبة ويُظهر الفقاعة. */
class MainActivity : Activity() {
    private val reqCapture = 7041
    private val reqNotif = 7042
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var statusView: TextView
    private lateinit var msgView: TextView
    private lateinit var sideBtn: Button
    private lateinit var stratBtn: Button
    private lateinit var skillBtn: Button
    private lateinit var remoteBtn: Button
    private var pending = false
    private val prompted = HashSet<String>()
    private var capWaits = 0

    private val refresh = object : Runnable { override fun run() { updateStatus(); ui.postDelayed(this, 500) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(refresh); ui.post(refresh)
        if (pending) ui.postDelayed({ if (pending) connect(true) }, 500)
    }

    override fun onPause() { ui.removeCallbacks(refresh); super.onPause() }

    // ---------------- الواجهة ----------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        setPadding(dp(12), dp(14), dp(12), dp(14))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
    }

    private fun buildUi() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(28)) }
        col.addView(TextView(this).apply {
            text = "Sideswipe AI"; setTextColor(Color.WHITE); textSize = 28f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "اضغط اتصال: يجهّز التطبيق الأذونات ثم يفتح اللعبة ويُظهر فقاعة التحكم"
            setTextColor(0xFFB0B8C8.toInt()); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(14))
        })
        col.addView(btn("اتصال", 0xFF2E7D32.toInt()) { prompted.clear(); capWaits = 0; connect(false) }.apply { textSize = 22f; setPadding(dp(12), dp(20), dp(12), dp(20)) })
        msgView = TextView(this).apply { setTextColor(0xFFFFD54F.toInt()); textSize = 14f; setPadding(0, dp(10), 0, dp(4)) }
        col.addView(msgView)
        statusView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { setColor(0xFF1B2130.toInt()); cornerRadius = dp(12).toFloat() }
        }
        col.addView(statusView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        sideBtn = btn("", 0xFF37474F.toInt()) {
            AutoPlayer.cfg = AutoPlayer.cfg.copy(attackRight = !AutoPlayer.cfg.attackRight); Store.saveConfig(this); updateStatus()
        }
        stratBtn = btn("", 0xFF37474F.toInt()) {
            val n = Strategies.names; val i = n.indexOf(AutoPlayer.cfg.strategy)
            AutoPlayer.cfg = AutoPlayer.cfg.copy(strategy = n[(i + 1) % n.size]); Store.saveConfig(this); updateStatus()
        }
        skillBtn = btn("", 0xFF37474F.toInt()) {
            val l = Skill.levels; val i = l.indexOf(AutoPlayer.cfg.skill)
            AutoPlayer.cfg = Skill.apply(AutoPlayer.cfg, l[(i + 1) % l.size]); Store.saveConfig(this); updateStatus()
        }
        remoteBtn = btn("", 0xFF37474F.toInt()) {
            if (!RemoteAdvisor.enabled && !RemoteAdvisor.url.startsWith("https://")) msg("أدخل عنوان الخدمة (https) أولًا")
            else { RemoteAdvisor.enabled = !RemoteAdvisor.enabled; RemoteAdvisor.status = "بانتظار أول رد"; Store.saveConfig(this); updateStatus() }
        }
        col.addView(sideBtn); col.addView(stratBtn); col.addView(skillBtn); col.addView(remoteBtn)
        col.addView(btn("عنوان خدمة AI الخارجية", 0xFF37474F.toInt()) { editRemoteUrl() })
        col.addView(btn("معايرة (اختياري)", 0xFF1565C0.toInt()) { openCalibration() })
        col.addView(btn("اختبار الأزرار: يسار / يمين / قفز / بوست (بعد 5 ث)", 0xFF455A64.toInt()) { testButtons() })
        col.addView(btn("إيقاف التحكم فورًا", 0xFFC62828.toInt()) { AutoPlayer.emergencyStop("إيقاف يدوي"); msg("أُوقف البوت") })
        col.addView(btn("قطع الاتصال (إيقاف الفقاعة والالتقاط)", 0xFF6D4C41.toInt()) { disconnect() })
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0E121B.toInt()); addView(col) })
    }

    private fun msg(s: String) { msgView.text = s }

    private fun editRemoteUrl() {
        val et = android.widget.EditText(this).apply {
            setText(RemoteAdvisor.url); hint = "https://example.com/decide"; setSingleLine(); layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        android.app.AlertDialog.Builder(this).setTitle("عنوان خدمة AI (https فقط)").setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty() && !u.startsWith("https://")) msg("العنوان يجب أن يبدأ بـ https://")
                else { RemoteAdvisor.url = u; if (u.isEmpty()) RemoteAdvisor.enabled = false; Store.saveConfig(this); updateStatus() }
            }.setNegativeButton("إلغاء", null).show()
    }

    // ---------------- الاتصال ----------------
    private fun halt(why: String) { pending = false; msg(why) }

    private fun connect(auto: Boolean) {
        pending = true
        // 1) الإشعارات (لزر الإيقاف في الإشعار؛ غير إلزامية)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            && "notif" !in prompted) {
            prompted += "notif"; requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif); return
        }
        // 2) الظهور فوق التطبيقات (للفقاعة)
        if (!Settings.canDrawOverlays(this)) {
            if (auto && "overlay" in prompted) { halt("لم يُمنح إذن الظهور فوق التطبيقات. اضغط اتصال للمحاولة مجددًا"); return }
            prompted += "overlay"
            msg("فعّل «السماح بالظهور فوق التطبيقات» لـ Sideswipe AI ثم ارجع")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        // 3) خدمة التحكم (لا يمكن تفعيلها برمجيًا؛ يفعّلها المستخدم مرة واحدة)
        if (TouchInjectorService.instance == null) {
            if (auto && "a11y" in prompted) { halt("خدمة التحكم غير مفعّلة. اضغط اتصال للمحاولة مجددًا"); return }
            prompted += "a11y"
            msg("فعّل «Sideswipe AI - التحكم باللمس» من إمكانية الوصول ثم ارجع. إن كان الخيار رماديًا: إعدادات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        // 4) التقاط الشاشة
        if (ScreenCaptureService.status == "awaiting_permission") return
        if (ScreenCaptureService.status != "running") {
            if (auto && "capture" in prompted) { halt("لم يبدأ التقاط الشاشة. اضغط اتصال للمحاولة مجددًا"); return }
            prompted += "capture"
            ScreenCaptureService.status = "awaiting_permission"
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture); return
        }
        // 5) كل شيء جاهز: الفقاعة ثم اللعبة
        pending = false; prompted.clear()
        if (!TouchController.ready()) Store.applyDefaultButtons()
        startForegroundService(Intent(this, BubbleService::class.java))
        if (GameLauncher.launch(this)) msg("تم الاتصال ✅ اضغط «تشغيل البوت» في الفقاعة عند بدء المباراة")
        else msg("تم الاتصال، لكن لعبة Rocket League Sideswipe غير مثبتة على هذا الهاتف")
    }

    private fun waitCapture() {
        when {
            ScreenCaptureService.status == "running" -> connect(true)
            ScreenCaptureService.status == "error" || ScreenCaptureService.status == "denied" || ++capWaits > 20 ->
                halt("تعذّر بدء الالتقاط: ${ScreenCaptureService.lastError.ifEmpty { ScreenCaptureService.status }}")
            else -> ui.postDelayed({ waitCapture() }, 300)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_CODE, resultCode).putExtra(ScreenCaptureService.EXTRA_DATA, data))
            capWaits = 0; waitCapture()
        } else { ScreenCaptureService.status = "denied"; halt("رُفض إذن التقاط الشاشة") }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        @Suppress("DEPRECATION") super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif && pending) connect(true)
    }

    private fun disconnect() {
        pending = false
        AutoPlayer.emergencyStop("قطع الاتصال")
        BubbleService.instance?.stopSelf()
        ScreenCaptureService.instance?.shutdown("stopped") ?: run { ScreenCaptureService.status = "stopped" }
        msg("تم قطع الاتصال")
    }

    // ---------------- معايرة واختبار ----------------
    private fun openCalibration() {
        if (ScreenCaptureService.status != "running") { msg("اضغط اتصال أولًا ليبدأ التقاط الشاشة"); return }
        startActivity(Intent(this, CalibrateActivity::class.java))
    }

    private fun testButtons() {
        val svc = TouchInjectorService.instance
        if (svc == null) { msg("خدمة التحكم غير مفعّلة"); return }
        if (!TouchController.ready()) Store.applyDefaultButtons()
        GameLauncher.launch(this)
        msg("انتقلت إلى اللعبة: ستُضغط الأزرار بالترتيب بعد 5 ثوانٍ. راقب هل تستجيب اللعبة")
        val (w, h) = svc.screenSize()
        var delay = 5000L
        for (b in TouchController.Btn.values()) {
            val p = TouchController.points[b] ?: continue
            ui.postDelayed({
                if (!svc.press(p.x * w, p.y * h, 700)) ErrLog.add("test", "رفض النظام اللمسة (${b.key})")
            }, delay)
            delay += 1500
        }
    }

    // ---------------- الحالة ----------------
    private fun mark(ok: Boolean) = if (ok) "✅" else "⬜"

    private fun updateStatus() {
        val notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val cap = ScreenCaptureService.status
        val auto = try { JSONObject(AutoPlayer.statusJson()) } catch (_: Exception) { JSONObject() }
        val lines = ArrayList<String>()
        lines += "${mark(notif)} الإشعارات"
        lines += "${mark(Settings.canDrawOverlays(this))} الظهور فوق التطبيقات"
        lines += "${mark(TouchInjectorService.instance != null)} خدمة التحكم باللمس"
        lines += "${mark(cap == "running")} التقاط الشاشة ($cap${if (cap == "running") "، إطارات: ${ScreenCaptureService.frameCount}" else ""})"
        lines += "${mark(GameLauncher.isInstalled(this))} اللعبة مثبتة"
        lines += "${mark(BubbleService.instance != null)} الفقاعة العائمة"
        lines += ""
        lines += "فحص الأزرار وحالة الاكتشاف:"
        for ((k, n) in Store.BTN_NAMES) {
            lines += when (Store.buttonState(k)) {
                0 -> "⬜ $n: غير مكتشف"
                1 -> "🟡 $n: موضع افتراضي — يحتاج تأكيد (معايرة)"
                else -> "✅ $n: مؤكد"
            }
        }
        lines += (if (Store.targetsCalibrated) "✅" else "🟡") + " الكرة والسيارتان: " +
            if (Store.targetsCalibrated) "معايَرة" else "ألوان افتراضية — تحتاج معايرة"
        val ready = notif && Settings.canDrawOverlays(this) && TouchInjectorService.instance != null &&
            cap == "running" && !Store.usingDefaultButtons && Store.targetsCalibrated
        val setup = when {
            ready -> "جاهز للعب"
            cap != "running" -> "يحتاج إلى إعداد: اضغط اتصال"
            Store.usingDefaultButtons || !Store.targetsCalibrated -> "يحتاج إلى إعداد: عايِر الأزرار والألوان"
            else -> "يحتاج إلى إعداد: أذونات ناقصة"
        }
        lines += "الحالة العامة: $setup"
        lines += "الخدمة الخارجية: " + RemoteAdvisor.statusLine()
        lines += "التعلّم (نظرة التوقع: متوسط جودة اللمسات): " + ParamTuner.summary()
        lines += ""
        lines += "البوت: " + (if (auto.optBoolean("running")) "يعمل — ${auto.optString("mode")} ${auto.optString("reason")}" else "متوقف")
        val err = auto.optString("err"); if (err.isNotEmpty()) lines += "⚠️ $err"
        statusView.text = lines.joinToString("\n")
        sideBtn.text = "جهة الهجوم: " + if (AutoPlayer.cfg.attackRight) "اليمين ◀" else "▶ اليسار"
        stratBtn.text = "الاستراتيجية: ${AutoPlayer.cfg.strategy} (اضغط للتبديل)"
        remoteBtn.text = "خدمة AI الخارجية: " + if (RemoteAdvisor.enabled) "مفعّلة (اضغط للتعطيل)" else "معطّلة (اضغط للتفعيل)"
        skillBtn.text = "مستوى المهارة: ${Skill.label(AutoPlayer.cfg.skill)} (اضغط للتبديل)"
    }
}
