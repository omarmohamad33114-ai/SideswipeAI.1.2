package com.sideswipeai.plugin.bubble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.sideswipeai.plugin.AppState
import com.sideswipeai.plugin.ErrLog
import com.sideswipeai.plugin.ScreenCaptureService
import com.sideswipeai.plugin.TouchInjectorService
import com.sideswipeai.plugin.ai.AutoPlayer
import com.sideswipeai.plugin.control.TouchController
import com.sideswipeai.plugin.vision.VisionEngine
import org.json.JSONObject
import kotlin.math.abs

/** فقاعة عائمة (WindowManager) للتحكم بالبوت أثناء اللعب. إزالتها توقف البوت دائمًا. */
class BubbleService : Service() {
    companion object {
        @Volatile var instance: BubbleService? = null
        private const val CHANNEL = "sideswipe_bubble"
    }

    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var botText: TextView? = null
    private var capText: TextView? = null
    private var msgText: TextView? = null
    private var btnText: TextView? = null
    private var aiText: TextView? = null
    private var bubble: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() { updateStatus(); ui.postDelayed(this, 500) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        try {
            startFg()
            AppState.ensureWired()
            ErrLog.dir = getExternalFilesDir(null)
            if (root == null) buildBubble()
            instance = this
            ui.removeCallbacks(refresh); ui.post(refresh)
        } catch (e: Exception) {
            ErrLog.add("bubble", e.message ?: e.javaClass.simpleName)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sideswipe AI - الفقاعة", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Sideswipe AI")
            .setContentText("الفقاعة العائمة ظاهرة")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun realMetrics(): DisplayMetrics {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm?.defaultDisplay?.getRealMetrics(m)
        return m
    }

    private fun buildBubble() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }

        val b = TextView(this).apply {
            text = "AI"; gravity = Gravity.CENTER; textSize = 16f
            setTextColor(0xFFB39DDB.toInt()); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF4527A0.toInt()); setStroke(dp(3), 0xFF7C4DFF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        bubble = b

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(10), dp(12), dp(10)); visibility = View.GONE
            background = GradientDrawable().apply { setColor(0xEE1A1330.toInt()); cornerRadius = dp(14).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
        }
        fun label(color: Int) = TextView(this).apply { setTextColor(color); textSize = 13f }
        botText = label(Color.WHITE); capText = label(0xFFD1C4E9.toInt()); msgText = label(0xFFFFAB91.toInt())
        btnText = label(0xFFFFF59D.toInt()); aiText = label(0xFFB2DFDB.toInt())
        p.addView(botText); p.addView(capText); p.addView(btnText); p.addView(aiText); p.addView(msgText)
        fun btn(t: String, c: Int, click: () -> Unit) = Button(this).apply {
            text = t; textSize = 14f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(c); cornerRadius = dp(10).toFloat() }
            minHeight = dp(40); minimumHeight = dp(40)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { topMargin = dp(6) }
            setOnClickListener { click() }
        }
        p.addView(btn("تشغيل البوت", 0xFF2E7D32.toInt()) { startBot() })
        p.addView(btn("إيقاف مؤقت / استئناف", 0xFFF9A825.toInt()) {
            if (AutoPlayer.paused) AutoPlayer.resume() else AutoPlayer.pause(); say("")
        })
        p.addView(btn("إيقاف البوت", 0xFFC62828.toInt()) { AutoPlayer.emergencyStop("إيقاف من الفقاعة"); say("") })
        p.addView(btn("الإعدادات والمعايرة", 0xFF1565C0.toInt()) {
            startActivity(Intent(this, com.sideswipeai.plugin.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        p.addView(btn("إخفاء الفقاعة", 0xFF455A64.toInt()) { stopSelf() })
        panel = p
        r.addView(b); r.addView(p)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }
        lp = params

        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var px = 0; var py = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = params.x; py = params.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) moved = true
                        if (moved) { params.x = px + dx.toInt(); params.y = py + dy.toInt(); clamp(); w.updateViewLayout(r, params); publishRect() }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        root = r
        w.addView(r, params)
        r.post { publishRect() }
    }

    private fun clamp() {
        val r = root ?: return; val params = lp ?: return
        val m = realMetrics()
        params.x = params.x.coerceIn(0, maxOf(0, m.widthPixels - r.width))
        params.y = params.y.coerceIn(0, maxOf(0, m.heightPixels - r.height))
    }

    private fun togglePanel() {
        val p = panel ?: return
        p.visibility = if (p.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        root?.post { clamp(); try { wm?.updateViewLayout(root, lp) } catch (_: Exception) {}; publishRect() }
    }

    private fun rectPx(): Rect? {
        val r = root ?: return null; val params = lp ?: return null
        return Rect(params.x, params.y, params.x + r.width, params.y + r.height)
    }

    /** يخبر الرؤية بمكان الفقاعة كي لا تُحسب كرة/سيارة. */
    private fun publishRect() {
        val rc = rectPx() ?: return
        val m = realMetrics()
        if (m.widthPixels <= 0 || m.heightPixels <= 0) return
        val mg = 0.01f
        VisionEngine.ignore = RectF(rc.left.toFloat() / m.widthPixels - mg, rc.top.toFloat() / m.heightPixels - mg,
            rc.right.toFloat() / m.widthPixels + mg, rc.bottom.toFloat() / m.heightPixels + mg)
    }

    /** لمسات البوت تمر على النافذة الموجودة عند الإحداثي؛ نرفض التشغيل إن غطّت الفقاعة زرًا معايَرًا. */
    private fun overlapMessage(): String {
        val s = TouchInjectorService.instance ?: return ""
        val rc = rectPx() ?: return ""
        val (w, h) = s.screenSize()
        val mg = dp(12)
        for (pt in TouchController.allPoints()) {
            val x = pt.x * w; val y = pt.y * h
            if (x >= rc.left - mg && x <= rc.right + mg && y >= rc.top - mg && y <= rc.bottom + mg)
                return "الفقاعة تغطي أحد أزرار اللعبة؛ حرّكها بعيدًا ثم أعد التشغيل"
        }
        return ""
    }

    private fun startBot() {
        panel?.visibility = View.GONE
        root?.post {
            clamp(); try { wm?.updateViewLayout(root, lp) } catch (_: Exception) {}
            publishRect()
            var e = overlapMessage()
            if (e.isEmpty()) e = AutoPlayer.start(3000, getExternalFilesDir(null))
            if (e.isNotEmpty()) { say(e); panel?.visibility = View.VISIBLE; root?.post { publishRect() } } else say("")
        }
    }

    private fun say(m: String) { msgText?.text = m }

    private fun updateStatus() {
        try {
            val st = JSONObject(AutoPlayer.statusJson())
            val running = st.optBoolean("running")
            val bot = when {
                running && st.optLong("armed_in") > 0 -> "البوت: يبدأ بعد ${st.optLong("armed_in")} ث"
                running && st.optBoolean("paused") -> "البوت: متوقف مؤقتًا"
                running && st.optString("mode") == "WAITING" -> "البوت: بانتظار بدء المباراة"
                running -> "البوت: يعمل (${st.optString("mode")})"
                st.optString("mode") == "STOPPED" -> "البوت: متوقف (${st.optString("reason")})"
                else -> "البوت: متوقف"
            }
            botText?.text = bot
            btnText?.text = "الأزرار: " + com.sideswipeai.plugin.Store.buttonSummary()
            aiText?.text = "الذكاء: ${st.optString("strategy")} | ${com.sideswipeai.plugin.ai.Skill.label(AutoPlayer.cfg.skill)} | الخدمة: ${com.sideswipeai.plugin.ai.remote.RemoteAdvisor.statusLine()}"
            val cap = when (ScreenCaptureService.status) {
                "running" -> "الالتقاط: يعمل"
                "awaiting_permission" -> "الالتقاط: بانتظار موافقتك"
                "denied" -> "الالتقاط: مرفوض"
                "error" -> "الالتقاط: خطأ"
                else -> "الالتقاط: غير مفعّل (ابدأ من التطبيق)"
            }
            capText?.text = cap + if (TouchInjectorService.instance == null) " | التحكم: غير مفعّل" else " | التحكم: مفعّل"
            (bubble?.background as? GradientDrawable)?.setStroke(dp(3), if (running) 0xFF66BB6A.toInt() else 0xFF7C4DFF.toInt())
        } catch (_: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        root?.post { clamp(); try { wm?.updateViewLayout(root, lp) } catch (_: Exception) {}; publishRect() }
    }

    override fun onDestroy() {
        ui.removeCallbacks(refresh)
        AutoPlayer.emergencyStop("إزالة الفقاعة")        // لا بوت سرّي بلا فقاعة
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null; VisionEngine.ignore = null; instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
