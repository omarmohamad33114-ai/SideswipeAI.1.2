package com.sideswipeai.plugin

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** سجل أخطاء مختصر (آخر 30) يُحفظ أيضًا في errors.log داخل مجلد ملفات التطبيق. */
object ErrLog {
    private class E(val t: Long, val src: String, val msg: String, var n: Int)
    private val items = ArrayDeque<E>()
    @Volatile var dir: File? = null

    @Synchronized fun add(src: String, msg: String) {
        val last = items.lastOrNull()
        if (last != null && last.src == src && last.msg == msg) { last.n++; return }
        val now = System.currentTimeMillis()
        items.addLast(E(now, src, msg, 1))
        while (items.size > 30) items.removeFirst()
        try { dir?.let { it.mkdirs(); File(it, "errors.log").appendText("$now [$src] $msg\n") } } catch (_: Exception) {}
    }

    @Synchronized fun json(): String {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("t", it.t).put("src", it.src).put("msg", it.msg).put("n", it.n)) }
        return a.toString()
    }

    @Synchronized fun clear() { items.clear() }
}
