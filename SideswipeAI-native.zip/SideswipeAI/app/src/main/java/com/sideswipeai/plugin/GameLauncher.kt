package com.sideswipeai.plugin

import android.content.Context
import android.content.Intent

/** يفتح لعبة Rocket League Sideswipe مباشرة إن كانت مثبتة. */
object GameLauncher {
    const val PKG = "com.Psyonix.RL2D"
    /** حزمة اللعبة الفعلية إن وُجدت مثبتة (تُحدَّث عند كل فحص)، وإلا null. */
    @Volatile var installedPkg: String? = null

    fun launchIntent(ctx: Context): Intent? {
        val pm = ctx.packageManager
        pm.getLaunchIntentForPackage(PKG)?.let { installedPkg = PKG; return it }
        // احتياط: ابحث بالاسم بين التطبيقات القابلة للتشغيل
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().contains("sideswipe", ignoreCase = true)
        } ?: return null
        installedPkg = hit.activityInfo.packageName
        return pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
    }

    fun isInstalled(ctx: Context) = launchIntent(ctx) != null

    /** يرجع true عند النجاح. */
    fun launch(ctx: Context): Boolean {
        val i = launchIntent(ctx) ?: return false
        return try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }
        catch (e: Exception) { ErrLog.add("game", e.message ?: "تعذر فتح اللعبة"); false }
    }
}
