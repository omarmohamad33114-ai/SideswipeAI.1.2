package com.sideswipeai.plugin.ai.remote

import com.sideswipeai.plugin.ErrLog
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * طبقة اتصال اختيارية بخدمة قرار خارجية (معطّلة افتراضيًا). لا يُرسَل أي صورة: فقط حالة مضغوطة
 * (مواضع وسرعات الكرة والسيارتين). الطلب غير حاجز وبمهلة قصيرة؛ الرد غير الصالح أو المتأخر يُهمل
 * ويستمر القرار المحلي. عنوان https فقط. لا مفاتيح داخل التطبيق: ضع المفتاح في الخادم الوسيط عندك.
 *
 * البروتوكول: POST JSON {t, ball:[x,y,vx,vy]|null, me:[..]|null, opp:[..]|null, attackRight, skill}
 * الرد: {"steer": -1|0|1, "boost": true|false, "jump": true|false}
 */
object RemoteAdvisor {
    class Hint(val steer: Int, val boost: Boolean, val jump: Boolean, val at: Long)

    @Volatile var enabled = false
    @Volatile var url = ""
    @Volatile var status = "معطّل"
    @Volatile var latencyMs = -1L
    @Volatile private var hint: Hint? = null
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()

    fun hintIfFresh(now: Long, maxAgeMs: Long = 600): Hint? = hint?.takeIf { now - it.at <= maxAgeMs }

    fun statusLine(): String = if (!enabled) "معطّل" else status + if (latencyMs >= 0) " (${latencyMs}ms)" else ""

    /** يتحقق من الرد: أي حقل ناقص أو خارج النطاق ⇒ null (يُهمل). */
    fun parse(body: String, now: Long): Hint? = try {
        val o = JSONObject(body)
        val steer = o.getInt("steer")
        if (steer !in -1..1) null
        else Hint(steer, o.getBoolean("boost"), o.getBoolean("jump"), now)
    } catch (_: Exception) { null }

    fun request(state: JSONObject) {
        val u = url
        if (!enabled || !u.startsWith("https://")) return
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            val t0 = System.currentTimeMillis()
            var c: HttpURLConnection? = null
            try {
                c = (URL(u).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 800; readTimeout = 800; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                c.outputStream.use { it.write(state.toString().toByteArray()) }
                if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val h = parse(body, System.currentTimeMillis())
                latencyMs = System.currentTimeMillis() - t0
                if (h == null) { hint = null; status = "رد غير صالح" } else { hint = h; status = "متصل" }
            } catch (e: Exception) {
                hint = null; latencyMs = -1
                status = "منقطع: ${e.message ?: e.javaClass.simpleName}".take(60)
                ErrLog.add("remote", status)
            } finally { c?.disconnect(); busy.set(false) }
        }
    }
}
