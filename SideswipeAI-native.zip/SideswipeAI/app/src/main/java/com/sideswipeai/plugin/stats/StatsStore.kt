package com.sideswipeai.plugin.stats

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * سجل جلسة لعب واحدة. الحقول القابلة للإلغاء (result/goals) تعني "غير معروف" وليست صفرًا:
 * النتيجة والأهداف لا تُكتشف بالرؤية، تُدخلها أنت يدويًا بعد الجلسة.
 */
data class SessionRecord(
    val id: Long, val strategy: String, val attackRight: Boolean,
    val startedAt: Long, val durationMs: Long,
    val frames: Int, val ballMissFrames: Int, val safeFrames: Int,
    val touches: Int, val goodTouches: Int,
    val stopKind: String, val stopReason: String,
    val result: String? = null, val goalsFor: Int? = null, val goalsAgainst: Int? = null
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("strategy", strategy).put("attackRight", attackRight)
        .put("startedAt", startedAt).put("durationMs", durationMs).put("frames", frames)
        .put("ballMissFrames", ballMissFrames).put("safeFrames", safeFrames)
        .put("touches", touches).put("goodTouches", goodTouches)
        .put("stopKind", stopKind).put("stopReason", stopReason)
        .apply {
            put("result", result ?: JSONObject.NULL)
            put("goalsFor", goalsFor ?: JSONObject.NULL)
            put("goalsAgainst", goalsAgainst ?: JSONObject.NULL)
        }

    companion object {
        fun fromJson(o: JSONObject) = SessionRecord(
            o.getLong("id"), o.getString("strategy"), o.optBoolean("attackRight", true),
            o.getLong("startedAt"), o.getLong("durationMs"), o.getInt("frames"),
            o.optInt("ballMissFrames", 0), o.optInt("safeFrames", 0),
            o.optInt("touches", 0), o.optInt("goodTouches", 0),
            o.optString("stopKind", "manual"), o.optString("stopReason", ""),
            if (o.isNull("result")) null else o.getString("result"),
            if (o.isNull("goalsFor")) null else o.getInt("goalsFor"),
            if (o.isNull("goalsAgainst")) null else o.getInt("goalsAgainst")
        )
    }
}

/** مقاييس مجمّعة لاستراتيجية واحدة. null = لا بيانات كافية لحسابها (وليس صفرًا). */
data class Summary(
    val strategy: String, val sessions: Int, val minutes: Double, val frames: Int,
    val ballMissRate: Double?, val touches: Int, val goodTouchRate: Double?,
    val controlStops: Int, val captureStops: Int,
    val knownResults: Int, val wins: Int, val winRate: Double?,
    val goalsFor: Int?, val goalsAgainst: Int?
) {
    fun toJson(): JSONObject = JSONObject().put("strategy", strategy).put("sessions", sessions)
        .put("minutes", minutes).put("frames", frames).put("touches", touches)
        .put("controlStops", controlStops).put("captureStops", captureStops)
        .put("knownResults", knownResults).put("wins", wins)
        .apply {
            put("ballMissRate", ballMissRate ?: JSONObject.NULL)
            put("goodTouchRate", goodTouchRate ?: JSONObject.NULL)
            put("winRate", winRate ?: JSONObject.NULL)
            put("goalsFor", goalsFor ?: JSONObject.NULL)
            put("goalsAgainst", goalsAgainst ?: JSONObject.NULL)
        }
}

/** تخزين محلي JSON في ملف واحد (كتابة عبر ملف مؤقت ثم إعادة تسمية). */
class StatsStore(private val file: File) {
    private val items = ArrayList<SessionRecord>()
    var loadError = ""; private set

    @Synchronized fun load() {
        items.clear(); loadError = ""
        if (!file.exists()) return
        try {
            val a = JSONObject(file.readText()).getJSONArray("sessions")
            for (i in 0 until a.length()) items += SessionRecord.fromJson(a.getJSONObject(i))
        } catch (e: Exception) {
            items.clear()
            loadError = "ملف الإحصائيات تالف؛ حُفظت نسخة .bak وبدأ سجل جديد"
            try { file.renameTo(File(file.path + ".bak")) } catch (_: Exception) {}
        }
    }

    @Synchronized fun save(): Boolean = try {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        val a = JSONArray(); items.forEach { a.put(it.toJson()) }
        tmp.writeText(JSONObject().put("version", 1).put("sessions", a).toString())
        if (file.exists()) file.delete()
        tmp.renameTo(file)
    } catch (e: Exception) { false }

    @Synchronized fun add(r: SessionRecord) {
        items += r
        while (items.size > MAX) items.removeAt(0)
        save()
    }

    /** يضبط نتيجة آخر جلسة. result: win | loss | draw. الأهداف اختيارية (null = غير معروفة). يرجع false إن لم توجد جلسة أو القيمة غير صالحة. */
    @Synchronized fun setLastResult(result: String, goalsFor: Int?, goalsAgainst: Int?): Boolean {
        if (items.isEmpty() || result !in setOf("win", "loss", "draw")) return false
        if ((goalsFor ?: 0) < 0 || (goalsAgainst ?: 0) < 0) return false
        val i = items.lastIndex
        items[i] = items[i].copy(result = result, goalsFor = goalsFor, goalsAgainst = goalsAgainst)
        return save()
    }

    @Synchronized fun clear() { items.clear(); save() }
    @Synchronized fun all(): List<SessionRecord> = items.toList()

    @Synchronized fun summaries(): List<Summary> = items.groupBy { it.strategy }.map { (name, l) ->
        val frames = l.sumOf { it.frames }
        val touches = l.sumOf { it.touches }
        val known = l.filter { it.result != null }
        val gf = l.filter { it.goalsFor != null }; val ga = l.filter { it.goalsAgainst != null }
        Summary(
            name, l.size, l.sumOf { it.durationMs } / 60000.0, frames,
            if (frames > 0) l.sumOf { it.ballMissFrames }.toDouble() / frames else null,
            touches, if (touches > 0) l.sumOf { it.goodTouches }.toDouble() / touches else null,
            l.count { it.stopKind == "control" }, l.count { it.stopKind == "capture" },
            known.size, known.count { it.result == "win" },
            if (known.isNotEmpty()) known.count { it.result == "win" }.toDouble() / known.size else null,
            if (gf.isNotEmpty()) gf.sumOf { it.goalsFor!! } else null,
            if (ga.isNotEmpty()) ga.sumOf { it.goalsAgainst!! } else null
        )
    }.sortedBy { it.strategy }

    @Synchronized fun toJson(): String {
        val s = JSONArray(); summaries().forEach { s.put(it.toJson()) }
        val r = JSONArray(); items.takeLast(15).reversed().forEach { r.put(it.toJson()) }
        return JSONObject().put("summaries", s).put("recent", r).put("total", items.size)
            .put("load_error", loadError).toString()
    }

    companion object { const val MAX = 500 }
}
