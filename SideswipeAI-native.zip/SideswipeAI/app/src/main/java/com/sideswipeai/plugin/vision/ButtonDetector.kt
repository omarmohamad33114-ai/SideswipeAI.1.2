package com.sideswipeai.plugin.vision

/**
 * اكتشاف أزرار اللعبة (تجريبي، قواعد لا نموذج تعلّم): يبحث عن كتل فاتحة قليلة التشبع (أيقونات الأزرار)
 * في ركني النصف السفلي من إطار أفقي. الثقة منخفضة دائمًا (≤ 0.5) لذلك لا يُعتمد أي نتيجة دون تأكيد المستخدم.
 * افتراضات غير مؤكدة: الزران اليساريان = يسار ثم يمين، والزران اليمينيان = القفز (الأصغر) والبوست (الأكبر).
 */
object ButtonDetector {
    class Cand(val key: String, val x: Float, val y: Float, val conf: Float)

    private class Cluster(var sx: Double, var sy: Double, var area: Int) {
        val cx get() = (sx / area).toFloat()
        val cy get() = (sy / area).toFloat()
    }

    fun detect(f: VisionEngine.Frame): List<Cand> {
        if (f.w < f.h) return emptyList()   // يلزم إطار أفقي (اللعبة في المقدمة)
        val w = f.w; val h = f.h; val n = w * h
        val y0 = (h * 0.5f).toInt()
        val mask = BooleanArray(n)
        for (y in y0 until h) for (x in 0 until w) {
            val nx = x.toFloat() / w
            if (nx > 0.38f && nx < 0.62f) continue   // وسط الملعب: خطوط وكرة
            val i = y * w + x
            if (f.sat[i] < 0.25f && f.value[i] > 0.82f) mask[i] = true
        }
        val q = IntArray(n)
        val clusters = ArrayList<Cluster>()
        for (s in 0 until n) {
            if (!mask[s]) continue
            var head = 0; var tail = 0
            q[tail++] = s; mask[s] = false
            var sx = 0.0; var sy = 0.0
            while (head < tail) {
                val p = q[head++]; val px = p % w; val py = p / w
                sx += px; sy += py
                if (px > 0 && mask[p - 1]) { mask[p - 1] = false; q[tail++] = p - 1 }
                if (px < w - 1 && mask[p + 1]) { mask[p + 1] = false; q[tail++] = p + 1 }
                if (py > 0 && mask[p - w]) { mask[p - w] = false; q[tail++] = p - w }
                if (py < h - 1 && mask[p + w]) { mask[p + w] = false; q[tail++] = p + w }
            }
            if (tail < 4 || tail > 600) continue
            val bx = ((sx / tail + 0.5) / w).toFloat(); val by = ((sy / tail + 0.5) / h).toFloat()
            // دمج الكتل القريبة (أجزاء أيقونة واحدة) في عنقود واحد
            val near = clusters.firstOrNull {
                val dx = Math.abs(it.cx - bx); val dy = Math.abs(it.cy - by) * h / w
                dx < 0.07f && dy < 0.07f
            }
            if (near != null) { near.sx += (bx * tail); near.sy += (by * tail); near.area += tail }
            else clusters.add(Cluster((bx * tail).toDouble(), (by * tail).toDouble(), tail))
        }
        val good = clusters.filter { it.area >= 10 }
        val left = good.filter { it.cx < 0.38f }.sortedBy { it.cx }
        val right = good.filter { it.cx > 0.62f }.sortedByDescending { it.area }.take(2)
        val out = ArrayList<Cand>()
        if (left.size >= 2) {
            out += Cand("btn_left", left[0].cx, left[0].cy, 0.45f)
            out += Cand("btn_right", left[1].cx, left[1].cy, 0.45f)
        } else if (left.size == 1) out += Cand("btn_left", left[0].cx, left[0].cy, 0.25f)
        if (right.size >= 2) {
            out += Cand("btn_boost", right[0].cx, right[0].cy, 0.4f)
            out += Cand("btn_jump", right[1].cx, right[1].cy, 0.4f)
        } else if (right.size == 1) out += Cand("btn_boost", right[0].cx, right[0].cy, 0.25f)
        return out
    }
}
