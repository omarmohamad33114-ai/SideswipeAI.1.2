package com.sideswipeai.plugin

import android.content.Context
import com.sideswipeai.plugin.ai.AutoPlayer
import com.sideswipeai.plugin.ai.Skill
import com.sideswipeai.plugin.ai.remote.RemoteAdvisor
import com.sideswipeai.plugin.ai.Strategies
import com.sideswipeai.plugin.control.TouchController
import com.sideswipeai.plugin.vision.VisionEngine
import org.json.JSONObject

/** حفظ/استرجاع المعايرة والإعدادات (SharedPreferences) + مواضع الأزرار الافتراضية. */
object Store {
    private const val P = "sideswipe"

    /**
     * مواضع افتراضية تقريبية (معيارية 0..1) لأزرار Rocket League Sideswipe في الوضع الأفقي.
     * غير مؤكدة على جهاز حقيقي: إن لم تستجب اللعبة كما ينبغي استخدم "معايرة" في التطبيق.
     */
    private val DEFAULT_BUTTONS = mapOf(
        "btn_left" to floatArrayOf(0.08f, 0.82f),
        "btn_right" to floatArrayOf(0.20f, 0.82f),
        "btn_jump" to floatArrayOf(0.80f, 0.82f),
        "btn_boost" to floatArrayOf(0.92f, 0.70f)
    )

    @Volatile var usingDefaultButtons = true
    /** هل عُوير الكرة والسيارتان فعليًا من المستخدم (وإلا فالألوان افتراضية تقريبية). */
    @Volatile var targetsCalibrated = false

    val BTN_NAMES = listOf("btn_left" to "يسار", "btn_right" to "يمين", "btn_jump" to "قفز", "btn_boost" to "بوست")

    /** حالة زر: 0 غير مكتشف، 1 افتراضي يحتاج تأكيد، 2 مؤكد. */
    fun buttonState(key: String): Int = when {
        TouchController.points.keys.none { it.key == key } -> 0
        usingDefaultButtons -> 1
        else -> 2
    }

    fun buttonSummary(): String = BTN_NAMES.joinToString("  ") { (k, n) ->
        n + when (buttonState(k)) { 2 -> " ✅"; 1 -> " 🟡"; else -> " ⬜" }
    }

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
        targetsCalibrated = sp.getString("targets", null) != null
        try { sp.getString("targets", null)?.let { VisionEngine.setTargetsJson(it) } } catch (e: Exception) { ErrLog.add("store", "targets: ${e.message}") }
        var loaded = false
        try {
            sp.getString("buttons", null)?.let { s ->
                val o = JSONObject(s)
                for (k in o.keys()) { val a = o.getJSONArray(k); TouchController.setPoint(k, a.getDouble(0).toFloat(), a.getDouble(1).toFloat()) }
                loaded = TouchController.ready() && sp.getBoolean("buttonsConfirmed", false)
            }
        } catch (e: Exception) { ErrLog.add("store", "buttons: ${e.message}") }
        usingDefaultButtons = !loaded
        if (!loaded) applyDefaultButtons()
        RemoteAdvisor.url = sp.getString("remoteUrl", "") ?: ""
        RemoteAdvisor.enabled = sp.getBoolean("remoteOn", false) && RemoteAdvisor.url.startsWith("https://")
        val strat = sp.getString("strategy", "smart") ?: "smart"
        AutoPlayer.cfg = Skill.apply(AutoPlayer.cfg.copy(
            attackRight = sp.getBoolean("attackRight", true),
            strategy = if (strat in Strategies.names) strat else "smart"
        ), sp.getString("skill", "medium") ?: "medium")
    }

    fun applyDefaultButtons() {
        DEFAULT_BUTTONS.forEach { (k, v) -> TouchController.setPoint(k, v[0], v[1]) }
        usingDefaultButtons = true
    }

    /** يحفظ المعايرة الحالية (الألوان + الأزرار). */
    fun saveCalibration(ctx: Context, buttonsCalibrated: Boolean) {
        if (buttonsCalibrated) usingDefaultButtons = false
        targetsCalibrated = true
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putString("targets", VisionEngine.targetsJson())
            .putString("buttons", TouchController.pointsJson())
            .putBoolean("buttonsConfirmed", !usingDefaultButtons)
            .apply()
    }

    fun saveConfig(ctx: Context) {
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
            .putBoolean("attackRight", AutoPlayer.cfg.attackRight)
            .putString("strategy", AutoPlayer.cfg.strategy)
            .putString("skill", AutoPlayer.cfg.skill)
            .putString("remoteUrl", RemoteAdvisor.url)
            .putBoolean("remoteOn", RemoteAdvisor.enabled)
            .apply()
    }
}
