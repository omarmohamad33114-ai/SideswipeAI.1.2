package com.sideswipeai.plugin.vision

import org.json.JSONArray
import org.json.JSONObject

/**
 * هل نحن داخل مباراة؟ أزرار القفز والبوست لا تظهر إلا أثناء اللعب (لا في القوائم ولا في لقطات إعادة الهدف).
 * أثناء المعايرة (من لقطة داخل مباراة) نحفظ "بصمة" أيقونة كل زر: أي بكسلات الدائرة أفتح من وسيط الدائرة.
 * أثناء التشغيل نقيس: نسبة تفتّح بكسلات الأيقونة ناقص نسبة تفتّح باقي الدائرة (قياس نسبي لا يتأثر بلون الخلفية).
 * القرار مُثبَّت بتأخير (3 إطارات للدخول، 8 للخروج) كي لا يتذبذب. دقّة تقديرية وغير مجرَّبة على جهاز.
 */
object MatchDetector {
    private class Ref(val cx: Int, val cy: Int, val r: Int, val bits: String)

    /** نصف قطر الزر كنسبة من عرض الشاشة (تقدير من لقطة الشاشة). */
    const val HUD_R = 0.05f
    private const val ENTER_SCORE = 0.28f

    @Volatile private var refs: List<Ref> = emptyList()
    @Volatile private var gridW = 0
    @Volatile var inMatch = false
    @Volatile var lastScore = 0f
    private var okRun = 0
    private var badRun = 0

    fun known(): Boolean = refs.isNotEmpty()
    /** -1 غير معروف (لم تُعايَر الأزرار داخل مباراة)، 0 خارج مباراة، 1 داخل مباراة. */
    fun state(): Int = if (!known()) -1 else if (inMatch) 1 else 0
    fun reset() { inMatch = false; okRun = 0; badRun = 0; lastScore = 0f }

    private fun median(f: VisionEngine.Frame, cx: Int, cy: Int, r: Int): Float {
        val vals = ArrayList<Float>()
        for (dy in -r..r) for (dx in -r..r) {
            if (dx * dx + dy * dy > r * r) continue
            vals += f.value[(cy + dy) * f.w + (cx + dx)]
        }
        vals.sort()
        return vals[vals.size / 2]
    }

    private fun bright(f: VisionEngine.Frame, i: Int, med: Float): Boolean =
        f.sat[i] < 0.4f && f.value[i] > med + 0.12f

    /** يتعلّم بصمة الأزرار من إطار داخل مباراة. يرجع false إن لم تبدُ الأيقونات واضحة. */
    @Synchronized fun learn(f: VisionEngine.Frame, centers: List<Pair<Float, Float>>, rNorm: Float): Boolean {
        val r = maxOf(4, (rNorm * f.w).toInt())
        val out = ArrayList<Ref>()
        for (c in centers) {
            val cx = (c.first * f.w).toInt(); val cy = (c.second * f.h).toInt()
            if (cx - r < 0 || cy - r < 0 || cx + r >= f.w || cy + r >= f.h) return false
            val med = median(f, cx, cy, r)
            val sb = StringBuilder()
            var icon = 0; var inside = 0
            for (dy in -r..r) for (dx in -r..r) {
                if (dx * dx + dy * dy > r * r) { sb.append('2'); continue }
                inside++
                if (bright(f, (cy + dy) * f.w + (cx + dx), med)) { sb.append('1'); icon++ } else sb.append('0')
            }
            if (icon < 5 || icon > inside / 2) return false
            out += Ref(cx, cy, r, sb.toString())
        }
        refs = out; gridW = f.w; reset()
        return out.isNotEmpty()
    }

    private fun scoreOf(f: VisionEngine.Frame, ref: Ref): Float {
        val r = ref.r
        if (ref.cx - r < 0 || ref.cy - r < 0 || ref.cx + r >= f.w || ref.cy + r >= f.h) return 0f
        val med = median(f, ref.cx, ref.cy, r)
        var ih = 0; var ic = 0; var bh = 0; var bc = 0; var k = 0
        for (dy in -r..r) for (dx in -r..r) {
            val ch = ref.bits[k++]
            if (ch == '2') continue
            val on = bright(f, (ref.cy + dy) * f.w + (ref.cx + dx), med)
            if (ch == '1') { ic++; if (on) ih++ } else { bc++; if (on) bh++ }
        }
        if (ic == 0 || bc == 0) return 0f
        return ih.toFloat() / ic - bh.toFloat() / bc
    }

    /** يُستدعى لكل إطار تُحلّله الرؤية. */
    @Synchronized fun update(f: VisionEngine.Frame) {
        val rs = refs
        if (rs.isEmpty() || f.w != gridW) return
        var sum = 0f
        for (r in rs) sum += scoreOf(f, r)
        val s = sum / rs.size
        lastScore = s
        if (s > ENTER_SCORE) { okRun++; badRun = 0; if (okRun >= 3) inMatch = true }
        else { badRun++; okRun = 0; if (badRun >= 8) inMatch = false }
    }

    fun toJson(): String {
        val a = JSONArray()
        for (r in refs) a.put(JSONObject().put("cx", r.cx).put("cy", r.cy).put("r", r.r).put("bits", r.bits))
        return JSONObject().put("w", gridW).put("refs", a).toString()
    }

    @Synchronized fun load(json: String) {
        try {
            val o = JSONObject(json); val a = o.getJSONArray("refs")
            val list = ArrayList<Ref>()
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                val r = x.getInt("r"); val bits = x.getString("bits")
                if (bits.length != (2 * r + 1) * (2 * r + 1)) throw IllegalArgumentException("بصمة تالفة")
                list += Ref(x.getInt("cx"), x.getInt("cy"), r, bits)
            }
            gridW = o.getInt("w"); refs = list; reset()
        } catch (_: Exception) { refs = emptyList() }
    }
}
