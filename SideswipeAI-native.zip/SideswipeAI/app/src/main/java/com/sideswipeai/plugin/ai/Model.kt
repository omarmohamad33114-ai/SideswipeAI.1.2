package com.sideswipeai.plugin.ai

/**
 * إحداثيات معيارية 0..1 (x يمين، y أسفل). السرعة بوحدة/ثانية.
 * conf: ثقة الاكتشاف 0..1 (تقدير استدلالي وليس احتمالًا معايَرًا).
 * vOk: هل السرعة مبنية على عدد كافٍ من الإطارات المتتالية؟ إن كانت false فالسرعة غير موثوقة.
 */
data class Obj(
    val x: Float, val y: Float, val vx: Float, val vy: Float,
    val conf: Float = 1f, val vOk: Boolean = true
)

data class World(val t: Long, val ball: Obj?, val me: Obj?, val opp: Obj?, val meFacing: Int = 0)

/**
 * mode: SEARCH | AIM | APPROACH | STRIKE | DEFENSE | HIGH_BALL | AIR | RECOVER | UNSTICK | SAFE | IDLE | CHASE
 * SAFE = لا مدخلات إطلاقًا لأن بيانات الرؤية غير موثوقة.
 */
data class Decision(
    val mode: String,
    val left: Boolean = false,
    val right: Boolean = false,
    val boost: Boolean = false,
    val jump: Boolean = false,
    val reason: String = ""
)

data class AiConfig(
    var attackRight: Boolean = true,
    var lookaheadSec: Float = 0.3f,
    var deadzone: Float = 0.02f,
    var minHoldMs: Long = 150,
    var behindOffset: Float = 0.12f,
    var jumpCooldownMs: Long = 900,
    var staleMs: Long = 700,
    var maxRunMs: Long = 10 * 60_000L,
    var strategy: String = "smart",
    /** مستوى المهارة: beginner | medium | advanced (انظر Skill) */
    var skill: String = "medium",
    /** احتمال "خطأ بشري" لكل قرار: يُسقط قفزة/بوست ذلك الإطار */
    var errorRate: Float = 0.03f,
    /** أقل ثقة لاعتبار الاكتشاف صالحًا */
    var minConf: Float = 0.35f,
    /** تسارع السقوط المعياري (y/ث²) — تقدير غير مقاس، يحتاج ضبطًا من سجلات حقيقية */
    var gravity: Float = 1.2f,
    /** سرعة السيارة الأفقية المعيارية (x/ث) — تقدير غير مقاس */
    var carSpeed: Float = 0.45f,
    /** الكرة غير ظاهرة: بعد هذه المدة ننتقل من الانتظار إلى البحث البطيء */
    var ballLostHoldMs: Long = 500,
    /** الكرة غير ظاهرة: بعد هذه المدة نتوقف تمامًا (SAFE) */
    var ballLostSafeMs: Long = 4000
)

/** مستويات المهارة: تغيّر توقيت الاستجابة والمخاطرة ونظرة التوقع وأخطاء بشرية، لا مجرد سرعة الضغط. */
object Skill {
    val levels = listOf("beginner", "medium", "advanced")
    fun label(l: String) = when (l) { "beginner" -> "مبتدئ"; "advanced" -> "متقدم"; else -> "متوسط" }

    fun apply(c: AiConfig, level: String): AiConfig = when (level) {
        "beginner" -> c.copy(skill = "beginner", deadzone = 0.05f, minHoldMs = 280, jumpCooldownMs = 1500,
            lookaheadSec = 0.15f, behindOffset = 0.18f, errorRate = 0.10f)
        "advanced" -> c.copy(skill = "advanced", deadzone = 0.015f, minHoldMs = 100, jumpCooldownMs = 700,
            lookaheadSec = 0.40f, behindOffset = 0.10f, errorRate = 0.0f)
        else -> c.copy(skill = "medium", deadzone = 0.02f, minHoldMs = 150, jumpCooldownMs = 900,
            lookaheadSec = 0.30f, behindOffset = 0.12f, errorRate = 0.03f)
    }
}
