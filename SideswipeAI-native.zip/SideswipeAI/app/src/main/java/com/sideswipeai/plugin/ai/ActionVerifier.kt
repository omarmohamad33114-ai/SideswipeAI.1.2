package com.sideswipeai.plugin.ai

import kotlin.math.abs

/**
 * يتحقق أن الأوامر تؤثر فعلًا على الشاشة: إن طُلب توجيه ثابت لنافذة زمنية ولم تتحرك السيارة المكتشفة،
 * يُحتسب فشل. بعد عدة نوافذ فاشلة متتالية يُعتبر التحكم غير فعّال (مثلًا اللعبة ترفض لمسات إمكانية الوصول).
 * لا يحكم عند عدم اكتشاف السيارة بثقة، ولا عندما تكون ملاصقة لحافة الملعب (قد تكون عالقة طبيعيًا).
 */
class ActionVerifier(
    private val windowMs: Long = 1500,
    private val minMove: Float = 0.01f,
    private val failLimit: Int = 3
) {
    private var wStart = 0L
    private var startX = 0f
    private var lastX = 0f
    private var frames = 0
    private var cmdFrames = 0
    private var dirSum = 0
    var fails = 0; private set

    fun reset() { wStart = 0L; frames = 0; cmdFrames = 0; dirSum = 0; fails = 0 }

    /** steer: -1 / 0 / +1 (الاتجاه المطلوب). يرجع true إذا تأكد أن التحكم غير فعّال. */
    fun feed(t: Long, steer: Int, carX: Float?, carConf: Float): Boolean {
        if (carX == null || carConf < 0.35f || carX < 0.04f || carX > 0.96f) { wStart = 0L; frames = 0; cmdFrames = 0; dirSum = 0; return false }
        if (wStart == 0L) { wStart = t; startX = carX; frames = 0; cmdFrames = 0; dirSum = 0 }
        frames++
        if (steer != 0) { cmdFrames++; dirSum += steer }
        lastX = carX
        if (t - wStart < windowMs) return false
        val steered = frames > 0 && cmdFrames >= frames * 0.7 && abs(dirSum) >= cmdFrames * 0.8
        if (steered) { if (abs(lastX - startX) < minMove) fails++ else fails = 0 }
        wStart = t; startX = carX; frames = 0; cmdFrames = 0; dirSum = 0
        return fails >= failLimit
    }
}
