package com.sideswipeai.plugin

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.sideswipeai.plugin.control.TouchController
import com.sideswipeai.plugin.vision.ButtonDetector
import com.sideswipeai.plugin.vision.VisionEngine

/**
 * معايرة على لقطة مجمّدة. أولًا يجرّب التطبيق اكتشاف الأزرار تلقائيًا ويعرض ما وجده بدوائر صفراء
 * (ثقة منخفضة دائمًا): تؤكده أو تعدّله يدويًا. ثم تلمس الكرة والسيارتين (وأي زر لم يُكتشف).
 */
class CalibrateActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val allSteps = listOf(
        "ball" to "المس الكرة",
        "my_car" to "المس سيارتك",
        "opp_car" to "المس سيارة الخصم",
        "btn_left" to "المس زر اليسار",
        "btn_right" to "المس زر اليمين",
        "btn_jump" to "المس زر القفز",
        "btn_boost" to "المس زر البوست"
    )
    private var steps = allSteps.toMutableList()
    private var idx = 0
    private var buttonsDone = 0
    private var choosing = false
    private var cands: List<ButtonDetector.Cand> = emptyList()
    private lateinit var prompt: TextView
    private lateinit var image: ImageView
    private lateinit var start: Button
    private lateinit var choiceRow: LinearLayout
    private val poll = object : Runnable {
        override fun run() {
            val jpg = VisionEngine.frozenJpeg
            if (jpg != null) { showFrame(jpg); return }
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0E121B.toInt()); setPadding(16, 12, 16, 12) }
        prompt = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            text = "اضغط «ابدأ» ثم انتقل إلى اللعبة (ابدأ تدريبًا) وانتظر 5 ثوانٍ ثم ارجع لهذه الشاشة"
        }
        start = Button(this).apply { text = "ابدأ (لقطة بعد 5 ثوانٍ)"; setOnClickListener { startFreeze() } }
        choiceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        choiceRow.addView(Button(this).apply { text = "تأكيد المكتشف"; setOnClickListener { confirmDetected() } },
            LinearLayout.LayoutParams(0, -2, 1f))
        choiceRow.addView(Button(this).apply { text = "معايرة يدوية"; setOnClickListener { goManual() } },
            LinearLayout.LayoutParams(0, -2, 1f))
        image = ImageView(this).apply {
            visibility = View.GONE; scaleType = ImageView.ScaleType.FIT_XY; adjustViewBounds = false
            setOnTouchListener { v, e -> if (e.action == MotionEvent.ACTION_DOWN && !choosing) onTap(e.x / v.width, e.y / v.height); true }
        }
        col.addView(prompt); col.addView(start); col.addView(choiceRow); col.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(col)
    }

    override fun onDestroy() { ui.removeCallbacks(poll); VisionEngine.clearFrozen(); super.onDestroy() }

    private fun startFreeze() {
        if (ScreenCaptureService.status != "running") { prompt.text = "التقاط الشاشة لا يعمل. ارجع واضغط اتصال"; return }
        VisionEngine.clearFrozen()
        VisionEngine.freezeAt = System.currentTimeMillis() + 5000
        prompt.text = "انتقل إلى اللعبة الآن وانتظر 5 ثوانٍ ثم ارجع إلى هنا (زر الرجوع/التطبيقات الأخيرة)"
        GameLauncher.launch(this)
        ui.removeCallbacks(poll); ui.postDelayed(poll, 6000)
    }

    private fun showFrame(jpg: ByteArray) {
        val bmp = BitmapFactory.decodeByteArray(jpg, 0, jpg.size) ?: run { prompt.text = "تعذّر قراءة اللقطة"; return }
        start.visibility = View.GONE
        idx = 0; buttonsDone = 0; steps = allSteps.toMutableList()
        cands = VisionEngine.detectButtons()
        image.setImageBitmap(if (cands.isEmpty()) bmp else drawCandidates(bmp, cands))
        image.visibility = View.VISIBLE
        if (cands.isEmpty()) {
            prompt.text = "لم يُكتشف أي زر تلقائيًا. عايِر يدويًا:\n" + steps[0].second
        } else {
            choosing = true; choiceRow.visibility = View.VISIBLE
            val names = cands.joinToString("، ") { Store.BTN_NAMES.firstOrNull { n -> n.first == it.key }?.second ?: it.key }
            prompt.text = "اكتُشف ${cands.size} من 4 أزرار بثقة منخفضة (الدوائر الصفراء: $names). إن كانت مطابقة اضغط «تأكيد المكتشف»، وإلا «معايرة يدوية»"
        }
    }

    private fun drawCandidates(src: Bitmap, list: List<ButtonDetector.Cand>): Bitmap {
        val b = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(b)
        val ring = Paint().apply { color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = b.width / 120f; isAntiAlias = true }
        val txt = Paint().apply { color = Color.YELLOW; textSize = b.width / 26f; isAntiAlias = true }
        for (k in list) {
            val x = k.x * b.width; val y = k.y * b.height
            c.drawCircle(x, y, b.width / 24f, ring)
            c.drawText(Store.BTN_NAMES.firstOrNull { it.first == k.key }?.second ?: k.key, x - b.width / 30f, y - b.width / 20f, txt)
        }
        return b
    }

    private fun confirmDetected() {
        for (k in cands) { TouchController.setPoint(k.key, k.x, k.y); buttonsDone++ }
        val done = cands.map { it.key }.toSet()
        steps.removeAll { it.first in done }
        choosing = false; choiceRow.visibility = View.GONE
        idx = 0; prompt.text = "تم تأكيد الأزرار المكتشفة. الآن: " + steps[0].second
    }

    private fun goManual() {
        choosing = false; choiceRow.visibility = View.GONE
        steps = allSteps.toMutableList(); buttonsDone = 0; idx = 0
        prompt.text = steps[0].second
    }

    private fun onTap(nx: Float, ny: Float) {
        if (idx >= steps.size) return
        val x = nx.coerceIn(0f, 1f); val y = ny.coerceIn(0f, 1f)
        val key = steps[idx].first
        if (key.startsWith("btn_")) { TouchController.setPoint(key, x, y); buttonsDone++ }
        else VisionEngine.calibrateAt(key, x, y)
        idx++
        if (idx >= steps.size) {
            Store.saveCalibration(this, buttonsDone >= 4)
            prompt.text = "تم حفظ المعايرة ✅ يمكنك الرجوع"
            ui.postDelayed({ finish() }, 1200)
        } else prompt.text = steps[idx].second
    }
}
