package com.sideswipeai.plugin.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

/**
 * تعلّم بسيط من النتائج (Bandit بأسلوب epsilon-greedy، وليس شبكة عصبية): يختار في كل جلسة قيمة "نظرة التوقع"
 * من ثلاث قيم، ويكافئها بنسبة لمسات الكرة الجيدة (باتجاه مرمى الخصم) من كل اللمسات المقدّرة بصريًا.
 * المكافأة تقدير بصري مشوّش، والعينات قليلة: لا تتوقع تحسنًا واضحًا قبل عشرات الجلسات.
 */
object ParamTuner {
    val arms = floatArrayOf(0.20f, 0.30f, 0.45f)
    private val n = IntArray(3)
    private val sum = DoubleArray(3)
    @Volatile var current = -1
    private var file: File? = null

    @Synchronized fun load(dir: File?) {
        file = dir?.let { File(it, "tuner.json") }
        n.fill(0); sum.fill(0.0); current = -1
        try {
            val f = file ?: return
            if (!f.exists()) return
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("n"); val s = o.getJSONArray("sum")
            for (i in arms.indices) { n[i] = a.getInt(i); sum[i] = s.getDouble(i) }
        } catch (_: Exception) { n.fill(0); sum.fill(0.0) }
    }

    @Synchronized private fun save() {
        try {
            val f = file ?: return
            f.parentFile?.mkdirs()
            val a = JSONArray(); val s = JSONArray()
            for (i in arms.indices) { a.put(n[i]); s.put(sum[i]) }
            f.writeText(JSONObject().put("n", a).put("sum", s).toString())
        } catch (_: Exception) {}
    }

    /** يختار ذراعًا لهذه الجلسة: يجرّب غير المجرَّب أولًا، ثم 20% استكشاف، وإلا الأفضل متوسطًا. */
    @Synchronized fun choose(rnd: Random = Random): Int {
        val untried = arms.indices.filter { n[it] == 0 }
        val i = when {
            untried.isNotEmpty() -> untried.random(rnd)
            rnd.nextFloat() < 0.2f -> arms.indices.random(rnd)
            else -> arms.indices.maxByOrNull { sum[it] / n[it] } ?: 1
        }
        current = i
        return i
    }

    /** يُستدعى عند نهاية جلسة صالحة. جلسات أقل من 3 لمسات مقدّرة لا تُحتسب (ضجيج). */
    @Synchronized fun finish(touches: Int, good: Int) {
        val i = current
        current = -1
        if (i < 0 || touches < 3) return
        sum[i] += good.toDouble() / touches
        n[i]++
        save()
    }

    @Synchronized fun summary(): String = arms.indices.joinToString(" | ") { i ->
        "${arms[i]}: " + if (n[i] == 0) "لم تُجرَّب" else "${"%.2f".format(sum[i] / n[i])} (${n[i]} جلسة)"
    }
}
