package com.sideswipeai.plugin.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import com.sideswipeai.plugin.ErrLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * نظام الرؤية (مستقل تمامًا عن القرار والتحكم): فصل ألوان HSV + أكبر كتلة متصلة + تتبع سرعة عبر الإطارات.
 * الألوان الافتراضية تقريبية؛ المعايرة من لقطة حقيقية مطلوبة.
 */
object VisionEngine {
    const val GRID_W = 160

    class Target(
        val name: String,
        var hMin: Float, var hMax: Float,
        var sMin: Float, var sMax: Float,
        var vMin: Float, var vMax: Float,
        var minPx: Int, var maxPx: Int
    ) {
        fun matches(h: Float, s: Float, v: Float): Boolean {
            if (s < sMin || s > sMax || v < vMin || v > vMax) return false
            return if (hMin <= hMax) h in hMin..hMax else (h >= hMin || h <= hMax)
        }
        fun toJson(): JSONObject = JSONObject().put("name", name)
            .put("hMin", hMin.toDouble()).put("hMax", hMax.toDouble())
            .put("sMin", sMin.toDouble()).put("sMax", sMax.toDouble())
            .put("vMin", vMin.toDouble()).put("vMax", vMax.toDouble())
            .put("minPx", minPx).put("maxPx", maxPx)
    }

    class Frame(val w: Int, val h: Int) {
        val hue = FloatArray(w * h); val sat = FloatArray(w * h); val value = FloatArray(w * h)
    }

    private class Det(val x: Float, val y: Float, val w: Float, val h: Float, val area: Int)

    val targets = LinkedHashMap<String, Target>().apply {
        put("ball", Target("ball", 0f, 360f, 0f, 0.18f, 0.85f, 1f, 3, 200))
        put("my_car", Target("my_car", 195f, 250f, 0.5f, 1f, 0.4f, 1f, 8, 800))
        put("opp_car", Target("opp_car", 10f, 40f, 0.6f, 1f, 0.5f, 1f, 8, 800))
    }

    @Volatile var enabled = false
    /** منطقة (معيارية 0..1) تُتجاهل في الكشف، مثل الفقاعة العائمة. */
    @Volatile var ignore: RectF? = null
    @Volatile var lastMs = 0L
    /** يستلم JSON نتيجة كل إطار؛ عقد الربط الوحيد مع نظام القرار. */
    @Volatile var resultListener: ((String) -> Unit)? = null
    @Volatile var lastJson = "{}"
    @Volatile var freezeAt = 0L
    @Volatile var frozenJpeg: ByteArray? = null
    private var frozen: Frame? = null
    private var lastFrame: Frame? = null
    private var frameId = 0L
    private val hist = HashMap<String, ArrayList<DoubleArray>>() // [t_sec, x, y]
    private var facing = 0

    @Synchronized fun process(bmp: Bitmap) {
        val now = System.currentTimeMillis()
        val doFreeze = freezeAt in 1..now
        if (!enabled && !doFreeze) return
        val t0 = System.nanoTime()
        val gh = max(8, bmp.height * GRID_W / bmp.width)
        val small = Bitmap.createScaledBitmap(bmp, GRID_W, gh, false)
        val frame = toFrame(small)
        if (small !== bmp) small.recycle()
        lastFrame = frame
        if (doFreeze) {
            frozen = frame
            val out = ByteArrayOutputStream(48 * 1024)
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
            frozenJpeg = out.toByteArray()
            freezeAt = 0
        }
        if (enabled) {
            val res = analyze(frame, now, true)
            lastMs = (System.nanoTime() - t0) / 1_000_000
            res.put("ms", lastMs)
            lastJson = res.toString()
            resultListener?.invoke(lastJson)
        }
    }

    private fun toFrame(b: Bitmap): Frame {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val f = Frame(w, h)
        val hsv = FloatArray(3)
        for (i in px.indices) {
            val c = px[i]
            Color.RGBToHSV(Color.red(c), Color.green(c), Color.blue(c), hsv)
            f.hue[i] = hsv[0]; f.sat[i] = hsv[1]; f.value[i] = hsv[2]
        }
        return f
    }

    private fun analyze(f: Frame, now: Long, track: Boolean): JSONObject {
        val objs = JSONObject()
        for (t in targets.values) {
            val d = detect(f, t)
            if (d == null) { if (track) prune(t.name, now); continue }
            val o = JSONObject().put("x", d.x.toDouble()).put("y", d.y.toDouble())
                .put("w", d.w.toDouble()).put("h", d.h.toDouble()).put("area", d.area)
            var vx = 0.0; var vy = 0.0; var n = 0; var jumped = false
            if (track) { val v = velocity(t.name, now, d.x, d.y); vx = v.vx; vy = v.vy; n = v.n; jumped = v.jumped }
            o.put("vx", vx).put("vy", vy)
                .put("conf", confidence(d, f, t, jumped))
                .put("vok", track && n >= 3)
            if (track && t.name == "my_car") {
                if (abs(vx) > 0.02) facing = if (vx > 0) 1 else -1
                o.put("facing", facing)
            }
            objs.put(t.name, o)
        }
        if (track) frameId++
        return JSONObject().put("frame", frameId).put("t", now).put("objs", objs)
    }

    private class Vel(val vx: Double, val vy: Double, val n: Int, val jumped: Boolean)

    /**
     * ثقة تقديرية 0..1 (استدلالية، ليست احتمالًا معايَرًا): امتلاء المستطيل المحيط (الدائرة ≈ 0.78)،
     * وقوع المساحة داخل المدى المتوقع، وغياب قفزة مفاجئة في الموضع بين إطارين.
     */
    private fun confidence(d: Det, f: Frame, t: Target, jumped: Boolean): Double {
        val bbox = max(1.0, d.w.toDouble() * f.w * d.h * f.h)
        val fill = d.area / bbox
        val shape = (1.0 - abs(fill - 0.75) / 0.6).coerceIn(0.2, 1.0)
        val size = if (d.area >= t.minPx * 1.5 && d.area <= t.maxPx * 0.8) 1.0 else 0.6
        val time = if (jumped) 0.4 else 1.0
        return (shape * size * time).coerceIn(0.0, 1.0)
    }

    /** سرعة بالوحدات المعيارية (0..1) في الثانية، انحدار خطي على آخر 500ms. n = عدد العينات (السرعة موثوقة عند 3+). */
    private fun velocity(name: String, now: Long, x: Float, y: Float): Vel {
        val list = hist.getOrPut(name) { ArrayList() }
        val ts = now / 1000.0
        var jumped = false
        if (list.isNotEmpty()) {
            val p = list.last()
            if (abs(p[1] - x) + abs(p[2] - y) > 0.35) { list.clear(); jumped = true }   // قفزة غير معقولة: ابدأ التتبع من جديد
        }
        list.add(doubleArrayOf(ts, x.toDouble(), y.toDouble()))
        list.removeAll { ts - it[0] > 0.5 }
        if (list.size < 2) return Vel(0.0, 0.0, list.size, jumped)
        val n = list.size
        val mt = list.sumOf { it[0] } / n
        var den = 0.0; var nx = 0.0; var ny = 0.0
        for (p in list) { val dt = p[0] - mt; den += dt * dt; nx += dt * p[1]; ny += dt * p[2] }
        if (den < 1e-9) return Vel(0.0, 0.0, n, jumped)
        return Vel(nx / den, ny / den, n, jumped)
    }

    private fun prune(name: String, now: Long) {
        val ts = now / 1000.0
        hist[name]?.removeAll { ts - it[0] > 0.6 }
    }

    private fun detect(f: Frame, t: Target): Det? {
        val w = f.w; val h = f.h; val n = w * h
        val ig = ignore
        val mask = BooleanArray(n)
        var any = false
        for (i in 0 until n) if (t.matches(f.hue[i], f.sat[i], f.value[i])) { mask[i] = true; any = true }
        if (!any) return null
        val q = IntArray(n)
        var best: Det? = null
        for (s in 0 until n) {
            if (!mask[s]) continue
            var head = 0; var tail = 0
            q[tail++] = s; mask[s] = false
            var minX = w; var maxX = -1; var minY = h; var maxY = -1
            var sx = 0L; var sy = 0L
            while (head < tail) {
                val p = q[head++]; val px = p % w; val py = p / w
                sx += px; sy += py
                if (px < minX) minX = px; if (px > maxX) maxX = px
                if (py < minY) minY = py; if (py > maxY) maxY = py
                if (px > 0 && mask[p - 1]) { mask[p - 1] = false; q[tail++] = p - 1 }
                if (px < w - 1 && mask[p + 1]) { mask[p + 1] = false; q[tail++] = p + 1 }
                if (py > 0 && mask[p - w]) { mask[p - w] = false; q[tail++] = p - w }
                if (py < h - 1 && mask[p + w]) { mask[p + w] = false; q[tail++] = p + w }
            }
            val area = tail
            if (area < t.minPx || area > t.maxPx) continue
            val det = Det((sx.toFloat() / area + 0.5f) / w, (sy.toFloat() / area + 0.5f) / h,
                (maxX - minX + 1f) / w, (maxY - minY + 1f) / h, area)
            if (ig != null && ig.contains(det.x, det.y)) continue
            if (best == null || area > best.area) best = det
        }
        return best
    }

    // ---- معايرة وإعدادات ----
    @Synchronized fun calibrateAt(name: String, nx: Float, ny: Float): String {
        val f = frozen ?: lastFrame ?: return ""
        val t = targets[name] ?: return ""
        val cx = (nx * f.w).toInt(); val cy = (ny * f.h).toInt()
        var sx = 0.0; var sy = 0.0; var ss = 0f; var sv = 0f; var c = 0
        for (dy in -2..2) for (dx in -2..2) {
            val x = (cx + dx).coerceIn(0, f.w - 1); val y = (cy + dy).coerceIn(0, f.h - 1)
            val i = y * f.w + x
            val r = Math.toRadians(f.hue[i].toDouble())
            sx += cos(r); sy += sin(r); ss += f.sat[i]; sv += f.value[i]; c++
        }
        val hMean = ((Math.toDegrees(atan2(sy, sx)) + 360) % 360).toFloat()
        val sM = ss / c; val vM = sv / c
        if (sM < 0.2f) { t.hMin = 0f; t.hMax = 360f; t.sMin = 0f; t.sMax = min(1f, sM + 0.15f) }
        else { t.hMin = (hMean - 15 + 360) % 360; t.hMax = (hMean + 15) % 360; t.sMin = max(0f, sM - 0.3f); t.sMax = 1f }
        t.vMin = max(0f, vM - 0.3f); t.vMax = 1f
        hist.remove(name)
        return t.toJson().toString()
    }

    @Synchronized fun detectButtons(): List<ButtonDetector.Cand> {
        val f = frozen ?: lastFrame ?: return emptyList()
        return try { ButtonDetector.detect(f) } catch (e: Exception) { ErrLog.add("buttons", e.message ?: "فشل الاكتشاف"); emptyList() }
    }

    @Synchronized fun analyzeFrozen(): String =
        frozen?.let { analyze(it, System.currentTimeMillis(), false).toString() } ?: "{}"

    @Synchronized fun clearFrozen() { frozen = null; frozenJpeg = null; freezeAt = 0 }

    fun targetsJson(): String { val a = JSONArray(); targets.values.forEach { a.put(it.toJson()) }; return a.toString() }

    @Synchronized fun setTargetsJson(json: String) {
        val a = JSONArray(json)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val t = targets[o.getString("name")] ?: continue
            t.hMin = o.getDouble("hMin").toFloat(); t.hMax = o.getDouble("hMax").toFloat()
            t.sMin = o.getDouble("sMin").toFloat(); t.sMax = o.getDouble("sMax").toFloat()
            t.vMin = o.getDouble("vMin").toFloat(); t.vMax = o.getDouble("vMax").toFloat()
            t.minPx = o.getInt("minPx"); t.maxPx = o.getInt("maxPx")
        }
    }
}
